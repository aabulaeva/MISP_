MISP
=========

An ansible role that install MISP on Ubuntu 20.04
INSTALL ANSIBLE
```
sudo apt update
sudo apt install software-properties-common
sudo apt-add-repository --yes --update ppa:ansible/ansible
sudo apt install ansible


```
INSTALL the role
----------------
```
ansible-galaxy install git+https://vcs-ecosystem.steria.fr/ansible/ssgcyber.misp.git, ssgcyber.misp_branch
```

Dependencies
------------

This role depends on the following ansible collections (see `meta/main.yml`):

```yaml
collections: 
  - community.mysql
  - community.general
roles:
  - geerlingguy.mysql
```

To install those depedencies use the following command:

```bash
ansible-galaxy collection install -r .ansible/roles/ssgcyber.misp/meta/requirements.yml
ansible-galaxy install -r .ansible/roles/ssgcyber.misp/meta/requirements.yml

```

Role Variables
--------------

Available variables are in  `defaults/main.yml`:
( modify them )

You can also manage the configuration of your MISP instance with the following variables (see `defaults/main.yml`):

```yaml
---
# defaults file for ssgcyber.misp
#you can fill with a non default port ( != 80/443) but you musp provide your certificat ssl
MISP_PORT: 443
MISP_URL: misp-test.ssg-cert.fr
MISP_HOSTNAME: "{{MISP_URL}}:{{MISP_PORT}}"
#MISP_IP: misp_ip
MISP_EMAIL: misp@local
MISP_VERSION: 2.4
MISP_USER: misp
MISP_PASSWORD: secured_password
MISP_ORGNAME: ORGNAME
WWW_USER: www-data
PATH_TO_MISP: /var/www/MISP
PATH_TO_MISP_SCRIPTS: /app/files/scripts
MISP_PASSWORD_POLICY: "/^((?=.*\\d)|(?=.*\\W+))(?![\\n])(?=.*[A-Z])(?=.*[a-z]).*$|.{16,}/"
HOME_PATH: /home/ubuntu
#Do you want install mariadb-server/client through geerlenguy role? default yes
INSTALL_MARIA: "yes"
#Do you have your own certifacat ssl ? default no
# you can customize the MISP_PORT
OWN_CERTIFICAT: "no"


#letsencrypt
#require url and port 443
CREATE_CERTIFICAT: "yes"
certbot_site_names: "{{MISP_URL}}"
 
certbot_package: "python3-certbot-apache"
certbot_plugin: "apache"
certbot_mail_address: cert@soprasteria.com
#HTTP ? ( port 80)
NO_CERTIFICAT: "no"

#new users
## extra users, the password is only valid once. user will be asked to update
## orgid (default): 1/ORGNAME
## roleid (default): 1/admin, 2/OrgAdmin, 3/user, 4/publisher, 5/sync user, 6/readonly
#example of users
# useful with a lot of users to register
#require a first launch of playbook and creation of misp_web_apikey in web interface with an admin account
misp_webusers_list:
   - { u: dupont pascal, p: 'dupont_passphrase.', email: dupont@localhost.com, org: 1, role: 2 }
   - { u: hello gmail, p: 'hello_passphrase.', email: hello@gmail.com, org: 1, role: 4 }
   - { u: hello test, p: 'hello_passphrase.', email: hooollo@gmail.com, org: 1, role: 4 }
## TODO: either fixed for serverspec test, either random if not defined/empty
misp_web_apikey: ""
misp_no_log: true
misp_pymisp_verifycert: False

```

As well as the Security parameters of your MISP instance (see `default/main.yml`):

```yaml
Security.password_policy_complexity: "{{MISP_PASSWORD_POLICY}}"
Security_password_policy_length: 12
Security_self_registration_message: 'If you would like to send us a registration request, please fill out the form below. Make sure you fill out as much information as possible in order to ease the task of the administrators.'
```


*Inside `vars/main.yml`*:

```yaml
---

MISP_EMAIL: cert@soprasteria.com 
MISP_ORGNAME: SopraSteria
MISP_VERSION: 2.4
MISP_USER: misp
MISP_PASSWORD: "1st_Secured_P@ssw0rd_here"

```

CREATE certificate
------------------
You can create your misp.local.key and misp.local.crt, then move them in .ansible/roles/misp-automation-box_pme/files.
Or use the CREATE_CERTIFICAT variable for the automatic generation of certificate( let's encrypt). 
You can run your misp instance without ssl

```
OWN_CERTIFICAT: "no"
CREATE_CERTIFICAT: yes
NO_CERTIFICAT: "no"
#misp running on port 80 but there is a proxy with certifcat ssl 
MISP_BEHIND_PROXY: "yes"

```
for example, this configuration will lead to the installation of let's encrypt certificate.

USE the geerlingguy mysql role
-----------------------------
You can launch the role in order to install mariadb-server and mariadb-client
```
INSTALL_MARIA: yes
```
RUN the playbook
----------------
Example Playbook is providen in this role ( )
you can run it: 
```
ansible-playbook .ansible/roles/ssgcyber.misp/playbook.yaml

```
After the execution
-------------------
- You can connect on the misp with "admin@admin.test" "admin"

![alt text](img/cap1.PNG?raw=true "Title")
- You will be asked to change the default password

![alt text](img/cap2.PNG?raw=true "Title")

- You must enable the taxonomy, see Event actions> list taxonomy
Enable SSG-GEO, SSG and tlp (id 5,6 and 114). ( click on the triangle)

![alt text](img/cap3.PNG?raw=true "Title")

- Now you must have
![alt text](img/cap4.PNG?raw=true "Title")

CREATE users through ansible ( **optionnal**** )
------------
- Create your api key, go to Administration > List users > admin > my profile > create Auth key
- Add your auth key ( replace the "")
- Add your users in the example way
- lauch again the playbook ( with misp_web_apikey in default/main.yml)

Create SERVERS for sync
-----------------------
- Get auth key of remote_user@soprasteria.com on each MISP ( https://misp)
- go to Sync Actions > List servers > new server
- 
FOR EACH MISP ( MISP SHARING PULL example)

- fill the form 
![alt text](img/cap5.PNG?raw=true "Title")
![alt text](img/cap6.PNG?raw=true "Title")
- make a pull all
![alt text](img/cap7.PNG?raw=true "Title")

- Now you will be able to see events in MISP
![alt text](img/cap8.PNG?raw=true "Title")


License
-------

SopraSteria Internal Use only.
