for x in {0..124}; do
       ./cake Admin enableTaxonomyTags "${x}";
       echo "hello";
done
