from setuptools import find_packages, setup


setup(
    name="eclecticiq-extension-misp",
    version="2.10.1",
    description="MISP",
    url="https://www.eclecticiq.com/",
    author="EclecticIQ",
    author_email="info@eclecticiq.com",
    license="Proprietary License",
    long_description="MISP",
    long_description_content_type="text/plain",
    classifiers=["Private :: Do Not Upload"],
    packages=find_packages(),
    install_requires=[
        "eclecticiq-platform-extensions-api == 2.10.*",
        "eclecticiq-extension-commons",
        "pymisp==2.4.121",
    ],
    include_package_data=True,
    entry_points={"eiq.extensions": ["misp = eiq.extensions.misp:prepare_extension"]},
)
