from typing import Any

from pymisp.api import PyMISP


def create_misp_client(
    misp_url: str, misp_key: str, ssl_verification: bool, task_parameters: dict
) -> Any:
    misp_key = misp_key.strip()
    use_cert_keys = task_parameters.get("use_ssl_keys")
    use_client_keys = task_parameters.get("use_client_keys")
    client_key = task_parameters.get("client_key")
    client_cert = task_parameters.get("client_cert")
    cert = None
    if use_client_keys:
        if client_key and client_cert:
            cert = (client_cert, client_key)
        elif client_cert:
            cert = client_cert

    if use_cert_keys:
        ssl_cert = task_parameters.get("ssl_cert")
        client = PyMISP(misp_url, misp_key, ssl=ssl_cert, cert=cert)
    else:
        client = PyMISP(misp_url, misp_key, ssl=ssl_verification, cert=cert)
    return client
