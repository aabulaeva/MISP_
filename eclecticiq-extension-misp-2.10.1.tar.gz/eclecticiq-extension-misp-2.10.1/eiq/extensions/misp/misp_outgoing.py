import json
from typing import Any

import pymisp
import structlog
from marshmallow import Schema, fields

from eiq_ext.legacy import BlacklistableUrl, IntegrationBase

from .packer import make_meta_attribute
from .utils import create_misp_client


log = structlog.get_logger(__name__)


class MISPIntegrationParametersSchema(Schema):
    misp_url = BlacklistableUrl(required=True)
    misp_key = fields.String(required=True)
    include_tags = fields.Boolean()
    ssl_validation = fields.Boolean()
    use_ssl_keys = fields.Boolean()
    use_client_keys = fields.Boolean()
    ssl_cert = fields.String()
    client_cert = fields.String()
    client_key = fields.String()


def update_noncomplete_events(misp_json: dict, misp: Any) -> None:
    for event_id, attrs in misp_json.get("attributes").items():
        log.info("Searching for MISP event.", event_uuid=event_id)
        response = misp.search(uuid=event_id)
        if "errors" in response:
            log.error("Errors occured while searching for event", error=str(response))
        if not response:
            log.info("Event not found", event_uuid=event_id, response=str(response))
        if response:
            event = response[0]["Event"]
            update_meta_entity(event, attrs)
            misp_json["events"].append(event)


def update_meta_entity(event: dict, attrs: list) -> None:
    attributes_to_add = []
    meta_entity = {
        "origin-id": "{http://misp-project.org}incident-" + event.get("uuid"),
        "entity-mappings": {"root": {"observables": []}},
    }
    for at in event["Attribute"]:
        if at.get("comment") == "MISP EIQ event metadata":
            meta_entity = json.loads(at["value"])
            event["Attribute"].remove(at)
            break
    for attr in attrs:
        if attr.get("object"):
            event["Object"].append(attr["object"])
            continue
        for _id in attr["versions"]:
            meta_entity["entity-mappings"].pop(_id, None)
        meta_entity["entity-mappings"][attr["stix_id"]] = attr["correlation"]
        attributes_to_add.extend(attr["attributes"])
    event["Attribute"].extend(attributes_to_add)
    event["Attribute"].append(make_meta_attribute(meta_entity, event["uuid"]))


def create_event(misp_json: dict, include_tags: bool) -> dict:
    events = []
    for event_json in misp_json.get("events"):
        event = pymisp.MISPEvent()
        if not include_tags:
            clear_tags(event_json)
        attributes = event_json.pop("Attribute")
        objects = event_json.pop("Object")
        event.from_dict(**event_json)
        for attr in attributes:
            event.add_attribute(attr.pop("type"), attr.pop("value"), **attr)
        for obj in objects:
            event.add_object(obj=obj)
        events.append(event)
    return events


def get_event_id(misp: Any, uuid: str) -> str:
    log.info("Searching for MISP event.", event_uuid=uuid)
    response = misp.search(uuid=uuid)
    if "errors" in response:
        log.error("Errors occured while searching for event", error=str(response))
    if not response:
        log.info("Event not found", event_uuid=uuid, response=str(response))
    if response:
        event = response[0]["Event"]
        return event["id"]


def clear_tags(event: dict) -> None:
    event.get("Tag", []).clear()
    for attribute in event.get("Attribute", []):
        attribute.get("Tag", []).clear()
    for obj in event.get("Object", []):
        for attribute in obj.get("Attribute", []):
            attribute.get("Tag", []).clear()


def add_or_update(misp: Any, event: dict) -> None:
    """
    Check if MISP event or attribute exist by UUID and then run action.

    :param misp: PyMISP client instance
    :param event: event with attributes
    """
    ev = {}
    _id = get_event_id(misp, event.uuid)
    if _id:
        try:
            log.info("Updating MISP event.", event_uuid=event.uuid)
            ev = misp.update_event(event_id=_id, event=event)
        except Exception as e:
            # pymisp does not list exceptions in docs so we must catch all exceptions.
            # Not a good practice but there is no other way since we have no idea
            # which exception may occur. We can speculate that RequestException is the
            # one we should catch.
            log.error("Exception occured while updating event", error=str(e))
            raise
    else:
        try:
            log.info("Adding MISP event.", event_uuid=event.uuid)
            ev = misp.add_event(event)
        except Exception as e:
            log.error("Exception occured while adding event", error=str(e))
            raise
    if "errors" in ev:
        log.error("Errors occured while updating/adding event", error=str(ev))


class MISPIntegration(IntegrationBase):
    title = "MISP upload"
    description = "Generic MISP upload"
    name = "eiq.outgoing-transports.misp_upload"
    content_groups = ["urn:misp_upload.com:json:1.0"]
    parameters_schema = MISPIntegrationParametersSchema()

    def push(
        self, task_parameters: dict, block_ids: list, attachment_ids: list = None
    ) -> dict:
        log.info("Outgoing transport started")
        misp_url = task_parameters.get("misp_url")
        misp_key = task_parameters.get("misp_key")
        ssl_verification = task_parameters.get("ssl_validation")
        include_tags = task_parameters.get("include_tags")

        misp = create_misp_client(misp_url, misp_key, ssl_verification, task_parameters)
        outgoing_feed = self.get_outgoing_feed()
        count = 0
        for block in self.get_content_blocks(outgoing_feed, block_ids):
            event_json = json.loads(block.data.decode())
            if event_json.get("attributes"):
                update_noncomplete_events(event_json, misp)
            events = create_event(event_json, include_tags)
            for event in events:
                add_or_update(misp, event)
            count += 1
        log.info("Outgoing transport finished successfully")
        return {"counter": count}

    @classmethod
    def ui_form_schema(cls) -> list:
        form_schema = [
            {
                "label": "MISP server URL",
                "name": "misp_url",
                "required": True,
                "type": "text",
            },
            {
                "label": "MISP server API key",
                "name": "misp_key",
                "type": "password",
                "required": True,
            },
            {
                "label": "Include tags",
                "name": "include_tags",
                "type": "checkbox",
                "default": True,
            },
            {
                "label": "SSL verification",
                "name": "ssl_validation",
                "type": "checkbox",
                "default": True,
                "hint": "Select to enable SSL verification",
            },
            {
                "label": "Use SSL cert keys",
                "name": "use_ssl_keys",
                "type": "checkbox",
                "default": False,
            },
            {
                "label": "Use client cert and key",
                "name": "use_client_keys",
                "type": "checkbox",
                "default": False,
            },
            {
                "label": "SSL cert location",
                "name": "ssl_cert",
                "type": "text",
                "when": {"use_ssl_keys": True},
                "hint": "/location/ssl.crt",
            },
            {
                "label": "Client cert location",
                "name": "client_cert",
                "type": "text",
                "when": {"use_client_keys": True},
                "hint": "/location/client.crt",
            },
            {
                "label": "Client key location",
                "name": "client_key",
                "type": "text",
                "when": {"use_client_keys": True},
                "hint": "/location/client.key",
            },
        ]

        return form_schema
