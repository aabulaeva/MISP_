import json
import uuid

import structlog

import eiq_ext
from eiq_ext import EnrichmentResult
from eiq_ext.legacy import transform_blob

from .misp_incoming import misp_content
from .utils import create_misp_client


log = structlog.get_logger(__name__)
MAX_PACKAGE_SIZE = 20000000  # 20MB
SUPPORTED_EXTRACT_TYPES = [
    "hash-md5",
    "hash-sha1",
    "hash-sha256",
    "name",
    "hash-sha512",
    "file",
    "ipv4",
    "ipv6",
    "domain",
    "email",
    "email-subject",
    "uri",
    "malware",
    "yara",
    "netname",
    "organization",
    "bank-account",
    "card",
    "actor-id",
    "telephone",
    "registrar",
    "port",
    "person",
    "country",
]


@eiq_ext.enricher_instance(
    version=4,
    name="MISP API Enricher",
    description="MISP API Enricher",
    is_active=False,
    api_url="",
    api_key="",
    ssl_validation=True,
    use_ssl_keys=False,
    use_client_keys=False,
    ssl_cert="",
    client_cert="",
    client_key="",
)
@eiq_ext.enricher(supported_extract_types=SUPPORTED_EXTRACT_TYPES)
@eiq_ext.extension.options.declare(
    api_url=eiq_ext.extension.options.url(
        label="API URL", hint="MISP API URL", required=True, default=""
    ),
    api_key=eiq_ext.extension.options.password(
        label="API key", hint="MISP API key", required=True
    ),
    ssl_validation=eiq_ext.extension.options.boolean(
        label="SSL verification",
        default=True,
        required=False,
        hint="Select to enable SSL verification.",
    ),
    use_ssl_keys=eiq_ext.options.boolean(label="Use SSL cert keys", default=False),
    use_client_keys=eiq_ext.options.boolean(
        label="Use client cert and key", default=False
    ),
    ssl_cert=eiq_ext.options.string(
        label="Path to SSL certificate file",
        hint="/location/ssl.crt",
        default="",
        required=False,
    ),
    client_cert=eiq_ext.options.string(
        label="Client cert location",
        hint="/location/client.crt",
        default="",
        required=False,
    ),
    client_key=eiq_ext.options.string(
        label="Client key location",
        hint="/location/client.key",
        default="",
        required=False,
    ),
)
def enrich_misp_events(
    extract_type: str,
    extract_value: str,
    api_url: str,
    api_key: str,
    ssl_validation: bool,
    use_ssl_keys: str,
    use_client_keys: str,
    ssl_cert: str = None,
    client_cert: str = None,
    client_key: str = None,
) -> EnrichmentResult:
    log.info("Enricher started")
    # Make connection to MISP
    misp = create_misp_client(
        api_url,
        api_key,
        ssl_validation,
        {
            "use_ssl_keys": use_ssl_keys,
            "ssl_cert": ssl_cert,
            "use_client_keys": use_client_keys,
            "client_cert": client_cert,
            "client_key": client_key,
        },
    )
    # Search MISP for events with extract_value attributes
    try:
        events = misp.search(value=f"%{extract_value}%", searchall=True)
    except Exception as e:
        # pymisp does not list exceptions in docs so we must catch all exceptions.
        # Not a good practice but there is no other way since we have no idea
        # which exception may occur. We can speculate that RequestException is the
        # one we should catch.
        log.error("Exception occured while searching event", error=str(e))
        raise
    if "errors" in events:
        log.error("Errors occured while searching for event", error=str(events))
    if not events:
        log.info("Nothing found", extract_value=extract_value, response=str(events))

    entities = []
    dropped_entities = []
    for entity in events:
        event = entity.get("Event")
        event["misp_url"] = api_url
        package = json.dumps(event)
        if package.__sizeof__() > MAX_PACKAGE_SIZE:
            dropped_entities.append(make_dropped_indicators(event))
            continue
        result = transform_blob(package, misp_content.id)
        entities.extend(result)
    entities.extend(dropped_entities)
    log.info("Enricher finished successfully")
    return eiq_ext.EnrichmentResult(
        raw_data=json.dumps(events).encode("utf-8"), entities=entities
    )


def make_dropped_indicators(package: str) -> dict:
    event = json.loads(package)
    reference = "{}/events/view/{}".format(
        event.get("misp_url").rstrip("/"), event.get("id")
    )
    indicator = {
        "data": {
            "id": "{{http://misp-project.org}}Indicator-{}".format(
                str(uuid.uuid5(uuid.NAMESPACE_X500, event.get("uuid")))
            ),
            "title": event.get("info"),
            "type": "indicator",
            "description": "dropped due to size",
            "information_source": {
                "references": [reference],
                "description": "Event Creator",
                "type": "information-source",
                "identity": {
                    "name": event.get("Orgc").get("name") or "",
                    "type": "identity",
                },
            },
        }
    }
    return {"type": "linked-entities", "entities": [indicator]}
