import datetime
import json
import random
import re
from typing import Any, Generator, Union

import structlog

import eiq_ext
from eiq.platform.helpers import validate_regex

from .utils import create_misp_client


log = structlog.get_logger(__name__)

OBSOLETE_TAGS = (
    "IDS",
    "MISP Distribution - Inherit",
    "MISP Distribution - Sharing Group",
)
DEFAULT_REQUEST_INTERVAL = 24 * 10  # 10 days
DEFAULT_SINCE_DAYS_AGO = 60
DEFAULT_EXCLUDE_AFTER_DATE_DAYS = 18250
DEFAULT_SINCE = datetime.datetime.utcnow() - datetime.timedelta(
    days=DEFAULT_SINCE_DAYS_AGO
)
DEFAULT_EXCLUDE_AFTER_DATE = datetime.datetime.utcnow() - datetime.timedelta(
    days=DEFAULT_EXCLUDE_AFTER_DATE_DAYS
)
MAX_PACKAGE_SIZE = 20000000  # 20MB
PACKAGE_SLICE_SIZE = 50

misp_content = eiq_ext.declare_content_type(
    id="urn:misp-project.com:json:1.0",
    name="MISP JSON",
    description="MISP JSON Content Type",
    content_groups=["misp", "generic"],
    file_extension="json",
    mime_type="application/json",
)


@eiq_ext.provider(  # noqa: C901
    name="misp",
    content_groups=["misp"],
    title="MISP API",
    description="MISP API transport",
    result_schema=eiq_ext.TimeframeProviderResultSchema,
)
@eiq_ext.options.declare(
    api_url=eiq_ext.options.url(label="MISP URL", hint="MISP URL", required=True),
    api_key=eiq_ext.options.password(label="MISP Key", hint="MISP Key", required=True),
    include_tags=eiq_ext.options.boolean(label="Include tags", default=True),
    prioritize_tlp=eiq_ext.options.boolean(
        label="Prioritize TLP tag",
        hint=(
            "Use TLP tags instead of MISP distribution values to set TLP values for "
            "entities in feed packages. If a TLP tag is not set, the MISP distribution "
            "used instead."
        ),
        default=False,
    ),
    include_ids=eiq_ext.options.boolean(
        label="Include IDS flag as tag",
        hint=(
            "Enable to preserve IDS flags in ingested MISP attributes. If a MISP "
            "attribute has the 'to_ids' flag set to true, add an 'IDS' tag to the "
            "resulting entity."
        ),
        default=True,
    ),
    performance=eiq_ext.options.boolean(
        label="Reduce lock contention",
        default=False,
        hint=(
            "Speed up ingestion by redistributing incoming data among ingestion"
            " workers. Entities will update in a random order. If you work with the da"
            "ta before ingestion finishes, you may find partially complete entities."
        ),
    ),
    ssl_validation=eiq_ext.options.boolean(
        label="SSL verification", hint="Select to enable SSL verification", default=True
    ),
    use_ssl_keys=eiq_ext.options.boolean(label="Use SSL cert keys", default=False),
    use_client_keys=eiq_ext.options.boolean(
        label="Use client cert and key", default=False
    ),
    polling_start_time=eiq_ext.options.datetime(
        label="Start ingesting from",
        hint="Fetch feed starting from specified date",
        default=DEFAULT_SINCE,
        required=True,
    ),
    polling_end_time=eiq_ext.options.datetime(
        label="End ingestion",
        hint="Fetch feed ending on specified date",
        default=datetime.datetime.now(),
        required=False,
    ),
    ssl_cert=eiq_ext.options.string(
        label="SSL cert location", hint="/location/ssl.crt", default="", required=False
    ),
    client_cert=eiq_ext.options.string(
        label="Client cert location",
        hint="/location/client.crt",
        default="",
        required=False,
    ),
    client_key=eiq_ext.options.string(
        label="Client key location",
        hint="/location/client.key",
        default="",
        required=False,
    ),
    request_interval=eiq_ext.options.integer(
        label="Default request interval",
        hint="Time interval (in hours) determining batch size when fetching"
        " data from MISP. Decrease this value if you encounter"
        " errors when pulling large amounts of data.",
        default=DEFAULT_REQUEST_INTERVAL,
        required=False,
    ),
    exclude_regex=eiq_ext.options.string(
        label="Filter by MISP event info",
        hint="Enter a regular expression. Excludes MISP events if the regular expression"
        " matches the contents of its 'Event Info' field.",
        default="",
        required=False,
        validate=validate_regex,
    ),
    exclude_org=eiq_ext.options.string(
        label="Filter by the creating organization's name",
        hint="Enter a regular expression. Excludes MISP events if the regular expression"
        " matches the the name of the creating organization.",
        default="",
        required=False,
        validate=validate_regex,
    ),
    exclude_after_date=eiq_ext.options.datetime(
        label="Ingest only the events created after this date",
        hint="Include only events created after the date provided.",
        default=DEFAULT_EXCLUDE_AFTER_DATE,
        required=False,
    ),
)
def fetch_misp_events(
    ctx: Any,
    api_url: str,
    api_key: str,
    include_tags: bool,
    prioritize_tlp: bool,
    include_ids: bool,
    performance: bool,
    ssl_validation: bool,
    use_ssl_keys: str,
    use_client_keys: str,
    polling_start_time: datetime,
    polling_end_time: datetime = None,
    ssl_cert: str = None,
    client_cert: str = None,
    client_key: str = None,
    request_interval: int = None,
    exclude_regex: str = "",
    exclude_org: str = "",
    exclude_after_date: datetime = None,
) -> dict:
    log.info("Provider started")
    since = ctx.get_since(polling_start_time)
    if exclude_after_date:
        exclude_after_date = exclude_after_date.strftime("%Y-%m-%d")

    if use_ssl_keys and not ssl_cert and not client_key:
        raise ValueError(
            "Please fill the certificate location "
            "if you want to use the SSL certificate."
        )
    request_interval = request_interval or DEFAULT_REQUEST_INTERVAL

    # Make connection to MISP
    misp = create_misp_client(
        api_url,
        api_key,
        ssl_validation,
        {
            "use_ssl_keys": use_ssl_keys,
            "ssl_cert": ssl_cert,
            "use_client_keys": use_client_keys,
            "client_cert": client_cert,
            "client_key": client_key,
        },
    )
    # Download all events with attributes in
    # DEFAULT DATE INTERVAL interval
    end_time = datetime.datetime.utcnow()
    events = {"response": []}
    while (since + datetime.timedelta(hours=request_interval)).replace(tzinfo=None) <= (
        polling_end_time if polling_end_time else end_time
    ).replace(tzinfo=None):
        poll_to = since + datetime.timedelta(hours=request_interval)
        events["response"].extend(
            search_misp(
                misp, (since.timestamp(), poll_to.timestamp()), exclude_after_date
            )
        )
        since = poll_to
    if polling_end_time:
        events["response"].extend(
            search_misp(
                misp,
                (since.timestamp(), polling_end_time.timestamp()),
                exclude_after_date,
            )
        )
    else:
        events["response"].extend(
            search_misp(misp, (since.timestamp()), exclude_after_date)
        )

    if events.get("response"):
        packages = []
        for entity in events.get("response"):
            try:
                event = entity.get("Event")
            except AttributeError:
                log.error(
                    "Response from search_misp is in unexpected format", response=entity
                )
                raise ValueError(
                    f"Response from search_misp is in unexpected format: {str(entity)}"
                )
            if check_regex_filter(event, exclude_regex, exclude_org):
                continue
            filter_tags_and_ids(event, include_tags, include_ids)
            event["misp_url"] = api_url
            event["prioritize_tlp"] = prioritize_tlp
            for slice_ in slice_package(event):
                packages.append(json.dumps(slice_))
        if performance:
            random.shuffle(packages)
        for package in packages:
            ctx.submit(package, content_type=misp_content.id)

    log.info("Provider finished successfully")
    return {
        "since": since,
        "until": polling_end_time or end_time,
        "initial_since": polling_start_time,
    }


def slice_package(package: dict) -> Generator:
    attributes = package.pop("Attribute")
    galaxy = package.pop("Galaxy")
    objects = package.pop("Object")
    counter = 0
    package["Attribute"] = []
    package["Galaxy"] = []
    package["Object"] = []
    for ent_list, name in [
        (attributes, "Attribute"),
        (galaxy, "Galaxy"),
        (objects, "Object"),
    ]:
        if ent_list:
            for ent in ent_list:
                package[name].append(ent)
                counter += 1
                if not counter % PACKAGE_SLICE_SIZE:
                    yield package
                    package[name] = []
            if package[name]:
                yield package
                package[name] = []
            counter = 0


def filter_tags_and_ids(event: dict, include_tags: bool, include_ids: bool) -> None:
    event["Tag"] = filter_tags(event.get("Tag", []), include_tags)
    for attribute in event.get("Attribute"):
        attribute["Tag"] = filter_tags(attribute.get("Tag", []), include_tags)
        if not include_ids:
            attribute["to_ids"] = False
    for obj in event.get("Object"):
        for attribute in obj.get("Attribute"):
            attribute["Tag"] = filter_tags(attribute.get("Tag", []), include_tags)
            if not include_ids:
                attribute["to_ids"] = False


def filter_tags(tags: list, include_tags: bool) -> list:
    filtered_tags = []
    for tag in tags:
        if (not include_tags and tag["name"].startswith("tlp")) or tag[
            "name"
        ] not in OBSOLETE_TAGS:
            filtered_tags.append(tag)
    return filtered_tags


def check_regex_filter(event: dict, exclude_regex: str, exclude_org: str) -> bool:
    if exclude_regex and re.search(exclude_regex, event.get("info", "")):
        return True
    if exclude_org and re.search(exclude_org, event.get("Orgc", {}).get("name", "")):
        return True
    return False


def search_misp(
    misp: Any, publish_timestamp: tuple, exclude_after_date: str
) -> Union[dict, list]:
    try:
        response = misp.search(
            publish_timestamp=publish_timestamp, date_from=exclude_after_date
        )
    except Exception as e:
        # pymisp does not list exceptions in docs so we must catch all exceptions.
        # Not a good practice but there is no other way since we have no idea
        # which exception may occur. We can speculate that RequestException is the
        # one we should catch.
        log.error("Exception occurred while searching event", error=str(e))
        raise
    # PyMISP.search() returns Union[str, list, dict] and we support only list or dict
    if type(response) == str:
        log.error(
            "Response from search_misp is in unexpected format", response=response
        )
        raise ValueError(
            f"Response from search_misp is in unexpected format: {str(response)}"
        )
    if type(response) == dict and "errors" in response:
        log.error("Errors occurred while searching for event", error=str(response))
        raise ValueError(
            f"Errors occurred while searching for event: {str(response['errors'])}"
        )
    if not response:
        log.info("Nothing found", response=str(response))
    return response
