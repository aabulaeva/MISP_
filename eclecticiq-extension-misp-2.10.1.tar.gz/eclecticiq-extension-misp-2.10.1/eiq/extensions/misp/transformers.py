import datetime
import json
import re
import uuid
import xml.sax.saxutils  # nosec
from typing import Optional, Tuple, Union

import structlog

from eiq.extensions.commons.entities import (
    create_course_of_action,
    create_incident,
    create_indicator,
    create_report,
    create_threat_actor,
    create_ttp,
)
from eiq.extensions.commons.utils import create_information_source
from eiq_ext import ExtractType, transformer
from eiq_ext.legacy import (
    TlpColor,
    get_latest_entity_version,
    resolve_external_taxonomy,
)

from .misp_incoming import misp_content


log = structlog.get_logger(__name__)

taxonomy_map = {
    # Kill chain taxonomies
    "kill-chain:Reconnaissance": "Kill chain phase - Reconnaissance",
    "kill-chain:Weaponization": "Kill chain phase - Weaponization",
    "kill-chain:Delivery": "Kill chain phase - Delivery",
    "kill-chain:Exploitation": "Kill chain phase - Exploitation",
    "kill-chain:Installation": "Kill chain phase - Installation",
    "kill-chain:Command and Control": "Kill chain phase - Command and Control",
    "kill-chain:Actions on Objectives": "Kill chain phase - Actions on Objectives",
    # Admiralty scale taxonomies
    # source-reliability
    'admiralty-scale:source-reliability="a"': "Admiralty Code - Completely reliable",
    'admiralty-scale:source-reliability="b"': "Admiralty Code - Usually reliable",
    'admiralty-scale:source-reliability="c"': "Admiralty Code - Fairly reliable",
    'admiralty-scale:source-reliability="d"': "Admiralty Code - Not usually reliable",
    'admiralty-scale:source-reliability="e"': "Admiralty Code - Unreliable",
    'admiralty-scale:source-reliability="f"': (
        "Admiralty Code - " "Reliability cannot be judged"
    ),
    # information-credibility
    'admiralty-scale:information-credibility="1"': (
        "Admiralty Code - " "Confirmed by other sources"
    ),
    'admiralty-scale:information-credibility="2"': "Admiralty Code - Probably True",
    'admiralty-scale:information-credibility="3"': "Admiralty Code - Possibly True",
    'admiralty-scale:information-credibility="4"': "Admiralty Code - Doubtful",
    'admiralty-scale:information-credibility="5"': "Admiralty Code - Improbable",
    'admiralty-scale:information-credibility="6"': (
        "Admiralty Code - " "Truth cannot be judged"
    ),
}

cybox_domain_name_format = """
    <cybox:Properties
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:cybox="http://cybox.mitre.org/cybox-2"
            xmlns:DomainNameObj="http://cybox.mitre.org/objects#DomainNameObject-1"
            xsi:type="DomainNameObj:DomainNameObjectType"
            type="FQDN">
        <DomainNameObj:Value><![CDATA[{}]]></DomainNameObj:Value>
    </cybox:Properties>"""

cybox_host_format = """
    <cybox:Properties
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:cybox="http://cybox.mitre.org/cybox-2"
            xmlns:HostnameObj="http://cybox.mitre.org/objects#HostnameObject-1"
            xsi:type="HostnameObj:HostnameObjectType">
        <HostnameObj:Hostname_Value><![CDATA[{}]]></HostnameObj:Hostname_Value>
    </cybox:Properties>
"""

cybox_ip_address_format = """
    <cybox:Properties
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:cybox="http://cybox.mitre.org/cybox-2"
            xmlns:AddressObj="http://cybox.mitre.org/objects#AddressObject-2"
            xsi:type="AddressObj:AddressObjectType"
            category="ipv4-addr">
        <AddressObj:Address_Value><![CDATA[{}]]></AddressObj:Address_Value>
    </cybox:Properties>"""

cybox_md5_format = """
    <cybox:Properties
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:cybox="http://cybox.mitre.org/cybox-2"
            xmlns:cyboxCommon="http://cybox.mitre.org/common-2"
            xmlns:cyboxVocabs="http://cybox.mitre.org/default_vocabularies-2"
            xmlns:FileObj="http://cybox.mitre.org/objects#FileObject-2"
            xsi:type="FileObj:FileObjectType">
            <FileObj:Hashes>
                <cyboxCommon:Hash>
                    <cyboxCommon:Type xsi:type=
                    "cyboxVocabs:HashNameVocab-1.0">MD5</cyboxCommon:Type>
                    <cyboxCommon:Simple_Hash_Value><![CDATA[{}]]></cyboxCommon:Simple_Hash_Value>
                </cyboxCommon:Hash>
            </FileObj:Hashes>
    </cybox:Properties>"""  # E501

cybox_sha1_format = """
    <cybox:Properties
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:cybox="http://cybox.mitre.org/cybox-2"
            xmlns:cyboxCommon="http://cybox.mitre.org/common-2"
            xmlns:cyboxVocabs="http://cybox.mitre.org/default_vocabularies-2"
            xmlns:FileObj="http://cybox.mitre.org/objects#FileObject-2"
            xsi:type="FileObj:FileObjectType">
        <FileObj:Hashes>
        <cyboxCommon:Hash>
            <cyboxCommon:Type xsi:type="cyboxVocabs:HashNameVocab-1.0">SHA1</cyboxCommon:Type>
            <cyboxCommon:Simple_Hash_Value><![CDATA[{}]]></cyboxCommon:Simple_Hash_Value>
        </cyboxCommon:Hash>
        </FileObj:Hashes>
</cybox:Properties>
"""  # noqa: E501

cybox_sha256_format = """
    <cybox:Properties
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:cybox="http://cybox.mitre.org/cybox-2"
            xmlns:cyboxCommon="http://cybox.mitre.org/common-2"
            xmlns:cyboxVocabs="http://cybox.mitre.org/default_vocabularies-2"
            xmlns:FileObj="http://cybox.mitre.org/objects#FileObject-2"
            xsi:type="FileObj:FileObjectType">
        <FileObj:Hashes>
        <cyboxCommon:Hash>
            <cyboxCommon:Type xsi:type="cyboxVocabs:HashNameVocab-1.0">SHA256</cyboxCommon:Type>
            <cyboxCommon:Simple_Hash_Value><![CDATA[{}]]></cyboxCommon:Simple_Hash_Value>
        </cyboxCommon:Hash>
        </FileObj:Hashes>
</cybox:Properties>
"""  # noqa: E501

cybox_sha512_format = """
    <cybox:Properties
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:cybox="http://cybox.mitre.org/cybox-2"
            xmlns:cyboxCommon="http://cybox.mitre.org/common-2"
            xmlns:cyboxVocabs="http://cybox.mitre.org/default_vocabularies-2"
            xmlns:FileObj="http://cybox.mitre.org/objects#FileObject-2"
            xsi:type="FileObj:FileObjectType">
        <FileObj:Hashes>
        <cyboxCommon:Hash>
            <cyboxCommon:Type xsi:type="cyboxVocabs:HashNameVocab-1.0">SHA512</cyboxCommon:Type>
            <cyboxCommon:Simple_Hash_Value><![CDATA[{}]]></cyboxCommon:Simple_Hash_Value>
        </cyboxCommon:Hash>
        </FileObj:Hashes>
</cybox:Properties>
"""  # noqa: E501

cybox_uri_format = """
    <cybox:Properties
            xmlns:cybox="http://cybox.mitre.org/cybox-2"
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:URIObj="http://cybox.mitre.org/objects#URIObject-2"
            xsi:type="URIObj:URIObjectType">
            <URIObj:Value condition="Equals"><![CDATA[{}]]></URIObj:Value>
    </cybox:Properties>"""

cybox_email_address_format = """
    <cybox:Properties
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:cybox="http://cybox.mitre.org/cybox-2"
            xmlns:AddressObj="http://cybox.mitre.org/objects#AddressObject-2"
            xsi:type="AddressObj:AddressObjectType"
            category="e-mail">
        <AddressObj:Address_Value><![CDATA[{}]]></AddressObj:Address_Value>
    </cybox:Properties>"""

cybox_file_name_format = """
    <cybox:Properties
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:cybox="http://cybox.mitre.org/cybox-2"
            xmlns:cyboxCommon="http://cybox.mitre.org/common-2"
            xmlns:cyboxVocabs="http://cybox.mitre.org/default_vocabularies-2"
            xmlns:FileObj="http://cybox.mitre.org/objects#FileObject-2"
            xsi:type="FileObj:FileObjectType">
        <FileObj:File_Name><![CDATA[{}]]></FileObj:File_Name>
    </cybox:Properties>
"""

cybox_mutex_format = """
    <cybox:Properties
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:cybox="http://cybox.mitre.org/cybox-2"
            xmlns:MutexObj="http://cybox.mitre.org/objects#MutexObject-2"
            xsi:type="MutexObj:MutexObjectType">
        <MutexObj:Name condition="Equals"><![CDATA[{}]]></MutexObj:Name>
    </cybox:Properties>"""

cybox_custom_format = """
    <cybox:Properties
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:cybox="http://cybox.mitre.org/cybox-2"
            xmlns:cyboxCommon="http://cybox.mitre.org/common-2"
            xmlns:cyboxVocabs="http://cybox.mitre.org/default_vocabularies-2"
            xmlns:CustomObj="http://cybox.mitre.org/objects#CustomObject-1"
            xsi:type="CustomObj:CustomObjectType">
            <cyboxCommon:Custom_Properties>
                <cyboxCommon:Property name="name">{}</cyboxCommon:Property>
            </cyboxCommon:Custom_Properties>
    </cybox:Properties>
"""

cybox_port_format = """
    <cybox:Properties
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xmlns:cybox="http://cybox.mitre.org/cybox-2"
        xmlns:PortObj="http://cybox.mitre.org/objects#PortObject-2"
        xsi:type="PortObj:PortObjectType">
            <PortObj:Port_Value><![CDATA[{}]]></PortObj:Port_Value>
    </cybox:Properties>
"""

cybox_email_subject_format = """
    <cybox:Properties
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xmlns:cybox="http://cybox.mitre.org/cybox-2"
            xmlns:EmailMessageObj="http://cybox.mitre.org/objects#EmailMessageObject-2"
            xsi:type="EmailMessageObj:EmailMessageObjectType">
        <EmailMessageObj:Header>
            <EmailMessageObj:Subject><![CDATA[{}]]></EmailMessageObj:Subject>
        </EmailMessageObj:Header>
    </cybox:Properties>"""


properties_xml_types = {
    "domain": (
        "{http://cybox.mitre.org/objects#DomainNameObject-1}" "DomainNameObjectType"
    ),
    "ip-src": "{http://cybox.mitre.org/objects#AddressObject-2}" "AddressObjectType",
    "ip-dst": "{http://cybox.mitre.org/objects#AddressObject-2}" "AddressObjectType",
    "md5": "{http://cybox.mitre.org/objects#FileObject-2}FileObjectType",
    "sha1": "{http://cybox.mitre.org/objects#FileObject-2}FileObjectType",
    "sha256": "{http://cybox.mitre.org/objects#FileObject-2}" "FileObjectType",
    "sha512": "{http://cybox.mitre.org/objects#FileObject-2}" "FileObjectType",
    "url": "{http://cybox.mitre.org/objects#URIObject-2}URIObjectType",
    "uri": "{http://cybox.mitre.org/objects#URIObject-2}URIObjectType",
    "email-src": (
        "{http://cybox.mitre.org/objects#AddressObject-2}" "AddressObjectType"
    ),
    "email-dst": (
        "{http://cybox.mitre.org/objects#AddressObject-2}" "AddressObjectType"
    ),
    "mutex_name": "{http://cybox.mitre.org/objects#MutexObject-2}" "MutexObjectType",
    "filename": "{http://cybox.mitre.org/objects#FileObject-2}" "FileObjectType",
    "filename|md5": "{http://cybox.mitre.org/objects#FileObject-2}" "FileObjectType",
    "filename|sha1": "{http://cybox.mitre.org/objects#FileObject-2}" "FileObjectType",
    "filename|sha256": "{http://cybox.mitre.org/objects#FileObject-2}" "FileObjectType",
    "hostname": "{http://cybox.mitre.org/objects#HostnameObject-1}"
    "HostnameObjectType",
    "link": "{http://cybox.mitre.org/objects#URIObject-2}URIObjectType",
    "target-email": "{http://cybox.mitre.org/objects#AddressObject-2}"
    "AddressObjectType",
    "malware-sample": "{http://cybox.mitre.org/objects#FileObject-2}" "FileObjectType",
    "attachment": "{http://cybox.mitre.org/objects#FileObject-2}" "FileObjectType",
    "email-attachment": "{http://cybox.mitre.org/objects#FileObject-2}"
    "FileObjectType",
    "email-subject": (
        "{http://cybox.mitre.org/objects#EmailMessageObject-2}" "EmailMessageObjectType"
    ),
    "other": "{http://cybox.mitre.org/objects#CustomObject-1}" "CustomObjectType",
    "port": "{http://cybox.mitre.org/objects#PortObject-2}PortObjectType",
}

formats = {
    "malware-sample": cybox_file_name_format,
    "domain": cybox_domain_name_format,
    "ip-src": cybox_ip_address_format,
    "ip-src|port": "In this case we are not using a cybox object",
    "ip-dst": cybox_ip_address_format,
    "ip-dst|port": "In this case we are not using a cybox object",
    "hostname": cybox_host_format,
    "md5": cybox_md5_format,
    "sha1": cybox_sha1_format,
    "sha256": cybox_sha256_format,
    "sha512": cybox_sha512_format,
    "url": cybox_uri_format,
    "uri": cybox_uri_format,
    "email-src": cybox_email_address_format,
    "email-dst": cybox_email_address_format,
    "target-email": cybox_email_address_format,
    "email-subject": cybox_email_subject_format,
    "filename": cybox_file_name_format,
    "filename|md5": cybox_md5_format,
    "filename|sha1": cybox_sha1_format,
    "filename|sha256": cybox_sha256_format,
    "mutex": cybox_mutex_format,
    "link": cybox_uri_format,
    "email-attachment": cybox_file_name_format,
    "attachment": cybox_file_name_format,
    "other": cybox_custom_format,
    "port": cybox_port_format,
}


extract_types = {
    "malware-sample": ExtractType.MALWARE,
    "domain": ExtractType.DOMAIN,
    "ip-src": ExtractType.IPV4,
    "ip-dst": ExtractType.IPV4,
    "hostname": ExtractType.HOST,
    "md5": ExtractType.HASH_MD5,
    "sha1": ExtractType.HASH_SHA1,
    "sha256": ExtractType.HASH_SHA256,
    "sha512": ExtractType.HASH_SHA512,
    "url": ExtractType.URI,
    "uri": ExtractType.URI,
    "email-src": ExtractType.EMAIL,
    "email-dst": ExtractType.EMAIL,
    "target-email": ExtractType.EMAIL,
    "email-subject": ExtractType.EMAIL_SUBJECT,
    "filename": ExtractType.FILE,
    "filename|md5": ExtractType.HASH_MD5,
    "filename|sha1": ExtractType.HASH_SHA1,
    "filename|sha256": ExtractType.HASH_SHA512,
    "mutex": ExtractType.MUTEX,
    "link": ExtractType.URI,
    "email-attachment": ExtractType.FILE,
    "attachment": ExtractType.FILE,
    "port": ExtractType.PORT,
}
distribution = {
    "0": "RED",
    "1": "AMBER",
    "2": "GREEN",
    "3": "WHITE",
    "4": None,
    "5": None,
}

MISP_CATEGORIES = [
    "Internal reference",
    "Targeting data",
    "Antivirus detection",
    "Payload delivery",
    "Artifacts dropped",
    "Payload installation",
    "Persistence mechanism",
    "Network activity",
    "Payload type",
    "Attribution",
    "External analysis",
    "Financial fraud",
    "Support Tool",
    "Social network",
    "Person",
    "Other",
]

YARA_NAME_REGEX = "rule (.+)\\s?{"
SNORT_NAME_REGEX = 'msg:\\s?"(.+?)"'


# Make report from event attributes
def make_report_attribute(
    attr: dict, event: dict, stix_id: str = None, corelation: dict = None
) -> dict:
    _uuid = str(
        uuid.uuid5(uuid.NAMESPACE_DNS, event["uuid"] + attr["value"] + attr["type"])
    )
    if not stix_id:
        stix_id = "{{http://misp-project.org}}report-{}".format(_uuid)
    latest_entity = get_latest_entity_version(stix_id)
    _id = stix_id if not latest_entity else latest_entity.meta.get("stix_id")

    corelation = corelation or {}
    description_meta = f"\neiq_meta:dist{attr['distribution']}"
    description_meta += f":event_uuid-{event['uuid']}"
    information_source = create_information_source(
        identity_name="",
        description="Event Creator",
        references=[attr["value"].replace("[.]", ".")]
        if attr["type"] == "link"
        else [],
    )
    tlp_from_tag = None
    if event.get("prioritize_tlp") and attr.get("Tag"):
        tlp_from_tag = get_tlp_from_tag(attr.get("Tag", []))
    tlp_colour = tlp_from_tag or distribution.get(str(attr.get("distribution")))

    tags = ["IDS"] if attr.get("to_ids") else None
    report = create_report(
        stix_id=_id,
        title=corelation.get("title")
        or "{} {}".format(event.get("info"), attr.get("id")),
        description=attr["value"] + description_meta,
        intents=[{"value": "Observations"}],
        timestamp=datetime.datetime.fromtimestamp(
            int(attr.get("timestamp", 0))
        ).isoformat(),
        threat_start_time=datetime.datetime.fromtimestamp(
            int(attr.get("timestamp", 0))
        ).isoformat(),
        relationship=corelation.get("relationship"),
        tags=tags,
        information_source=information_source,
        tlp_color=tlp_colour,
    )
    return report


def get_yara_name(yara_string: str) -> str:
    m = re.search(YARA_NAME_REGEX, yara_string)
    if m:
        return m.group(1)
    else:
        return "unknown"


def get_snort_message(snort_string: str) -> str:
    m = re.search(SNORT_NAME_REGEX, snort_string)
    if m:
        return m.group(1)
    else:
        return "unknown"


def make_indicator(
    attribute: dict,
    event_uuid: str = "",
    stix_id: str = None,
    observables: list = None,
    correlation: dict = None,
    prioritize_tlp: bool = None,
) -> dict:

    attribute["value"] = sanitize_string(attribute["value"])
    correlation = correlation or {}

    _uuid = str(
        uuid.uuid5(
            uuid.NAMESPACE_DNS, event_uuid + attribute["value"] + attribute["type"]
        )
    )
    stix_id = stix_id or "{{http://misp-project.org}}indicator-{}".format(_uuid)
    observables = observables or []
    description = []
    observables.extend(make_observables(attribute))

    description.append(sanitize_description(attribute))

    if attribute.get("comment"):
        description.append("Comment: {}".format(attribute.get("comment")))
    latest_entity = get_latest_entity_version(stix_id)
    _id = stix_id if not latest_entity else latest_entity.meta.get("stix_id")
    information_source = create_information_source(
        identity_name="",
        description="Event Creator",
    )
    tlp_from_tag = None
    if prioritize_tlp and attribute.get("Tag"):
        tlp_from_tag = get_tlp_from_tag(attribute.get("Tag", []))
    tlp_colour = tlp_from_tag or distribution.get(str(attribute.get("distribution")))
    description_meta = f"eiq_meta:dist{attribute['distribution']}"
    if attribute.get("object_relation"):
        description_meta += f":obj_rel-{attribute['object_relation']}"
    if event_uuid:
        description_meta += f":event_uuid-{event_uuid}"
    description.append(description_meta)
    description = "\n".join(description)
    tags = ["IDS"] if attribute.get("to_ids") else None
    indicator = create_indicator(
        stix_id=_id,
        title=correlation.get("title") or attribute.get("value"),
        description=description,
        timestamp=datetime.datetime.fromtimestamp(
            int(attribute.get("timestamp", 0))
        ).isoformat(),
        threat_start_time=datetime.datetime.fromtimestamp(
            int(attribute.get("timestamp", 0))
        ).isoformat(),
        relationship=correlation.get("relationship"),
        tags=tags,
        information_source=information_source,
        tlp_color=tlp_colour,
        observable=observables,
    )
    handle_yara_and_snort_attribute(attribute, indicator)
    return indicator


def handle_yara_and_snort_attribute(attribute: dict, indicator: dict) -> None:
    if attribute.get("type") in ["yara", "snort"]:
        indicator["data"]["test_mechanisms"] = add_yara_or_snort_rule(attribute)
        title = "Unknown rule"
        if attribute.get("type") == "yara":
            title = "YARA: {}".format(get_yara_name(attribute.get("value")))
        elif attribute.get("type") == "snort":
            title = "SNORT: {}".format(get_snort_message(attribute.get("value")))
        indicator["data"]["title"] = title


def get_attribute_by_uuid(event: dict, _uuid: str) -> Optional[dict]:
    for i, attribute in enumerate(event.get("Attribute")):
        extract_uuid = uuid.uuid5(
            uuid.NAMESPACE_DNS, event["uuid"] + attribute["value"] + attribute["type"]
        )
        if _uuid == attribute.get("uuid") or _uuid == extract_uuid:
            return event.get("Attribute")[i]


def make_indicators_and_reports(event: dict, correlation: dict) -> tuple:
    indicators, reports = [], []
    all_observables_uuids = []
    if correlation:
        for key, value in correlation["entity-mappings"].items():
            all_observables_uuids.extend(value["observables"])
            if key == "root":
                continue
            if not value.get("observables"):
                continue
            attribute = get_attribute_by_uuid(event, value["observables"][0])
            if not attribute:
                continue
            stix_id = key
            observables = make_observables_from_uuid(event, value["observables"])
            if attribute.get("category") == "External analysis" and attribute.get(
                "type"
            ) in ["link", "text", "attachment"]:
                report = make_report_attribute(attribute, event, stix_id, value)
                add_taxonomies_and_tags_to_entities([report], attribute.get("Tag", []))
                reports.append(report)
                continue
            indicator = make_indicator(
                attribute,
                event_uuid=event["uuid"],
                stix_id=stix_id,
                observables=observables,
                correlation=value,
                prioritize_tlp=event.get("prioritize_tlp"),
            )
            add_taxonomies_and_tags_to_entities([indicator], attribute.get("Tag", []))
            indicators.append(indicator)

    for attribute in event.get("Attribute"):
        all_observables_uuids.append(
            uuid.uuid5(
                uuid.NAMESPACE_DNS,
                event["uuid"] + attribute["value"] + attribute["type"],
            )
        )
        if attribute.get("uuid") in all_observables_uuids:
            continue
        if attribute.get("category") == "External analysis" and attribute.get(
            "type"
        ) in ["link", "text", "attachment"]:
            report = make_report_attribute(attribute, event)
            add_taxonomies_and_tags_to_entities([report], attribute.get("Tag", []))
            reports.append(report)
            continue
        indicator = make_indicator(
            attribute,
            event_uuid=event["uuid"],
            prioritize_tlp=event.get("prioritize_tlp"),
        )
        add_taxonomies_and_tags_to_entities([indicator], attribute.get("Tag", []))
        indicators.append(indicator)

    # Add references
    set_reference(indicators, event.get("misp_url"), event.get("id"))
    set_reference(reports, event.get("misp_url"), event.get("id"))

    # Transformer indicators
    # Add taxonomies and tags to indicators
    # add_taxonomies_and_tags_to_entities(indicators, event)

    # Transformer reports
    # Add taxonomies and tags to reports
    # add_taxonomies_and_tags_to_entities(reports, event)

    return indicators, reports


def set_marking_structure(tlp: str, marking_structure: str) -> list:
    return [
        {
            "marking_structures": [
                {
                    "color": tlp,
                    "marking_structure_type": "tlp",
                    "type": "marking-structure",
                },
                {
                    "type": "marking-structure",
                    "statement": marking_structure,
                    "marking_structure_type": "simple",
                },
            ],
            "type": "marking-specification",
        }
    ]


def add_taxonomies_and_tags_to_entities(
    entities: list, input_tags: list, timestamp: str = None
) -> None:
    tlps = []
    taxonomies = []
    tags = []
    marking_structure = None

    if input_tags:
        for tag in input_tags:
            if tag["name"].startswith("tlp"):
                tlp_values = tag["name"].split(":")[1].split(" ")
                tlp = tlp_values[0]
                if len(tlp_values) > 1:
                    marking_structure = tlp_values[1]
                tlps.append(tlp.upper())
                continue
            if tag["name"] in list(taxonomy_map.keys()):
                taxonomies.extend(
                    resolve_external_taxonomy([tag.get("name")], key=taxonomy_map.get)
                )
                continue
            tags.append(tag.get("name"))

    assign_tags(entities, tlps, marking_structure, taxonomies, tags, timestamp)


def assign_tags(
    entities: list,
    tlps: list,
    marking: str,
    taxonomies: list,
    tags: list,
    timestamp: str,
) -> None:
    for entity in entities:
        if entity.get("object"):
            assign_tags(
                entity.get("object"), tlps, marking, taxonomies, tags, timestamp
            )
        if entity.get("object_indicators"):
            assign_tags(
                entity.get("object_indicators"),
                tlps,
                marking,
                taxonomies,
                tags,
                timestamp,
            )
        else:
            if (
                not entity["meta"].get("tlp_color")
                and tlps
                and ":dist4" not in entity["data"].get("description", "")
            ):
                entity["meta"]["tlp_color"] = get_most_restrictive(tlps)
            if entity["data"]["type"] == "indicator" and marking:
                entity["data"]["handling"] = set_marking_structure(
                    entity["meta"]["tlp_color"], marking
                )

            entity["meta"]["taxonomy"] = entity["meta"].get("taxonomy", []) + taxonomies
            if entity["meta"].get("tags"):
                entity["meta"]["tags"].extend(tags)
            else:
                entity["meta"]["tags"] = tags[:]
            entity["meta"]["tags"] = list(set(entity["meta"]["tags"]))
            if timestamp:
                entity["data"]["timestamp"] = max(
                    entity["data"].get("timestamp", timestamp), timestamp
                )


def get_tlp_from_tag(tags: list) -> Optional[str]:
    tlps = []
    for tag in tags:
        if tag["name"].startswith("tlp"):
            tlp = tag["name"].split(":")[1].split(" ")[0]
            tlps.append(tlp.upper())
    return get_most_restrictive(tlps)


RELATIONS = {
    "ttp": "leveraged_ttps",
    "threat-actor": "attributed_threat_actors",
    "course-of-action": "coas_taken",
}


def get_relation_key(entity_data: dict) -> str:
    if entity_data.get("type") in ["ttp", "threat-actor", "course-of-action"]:
        return RELATIONS.get(entity_data.get("type"))


# Link incident, indicator, reports, ttp, misp_objects and galaxies
def make_linked_entities_iirt(
    incident: dict,
    indicators: list,
    reports: list,
    misp_objects: list,
    galaxy_clusters: list,
) -> dict:
    entities = [incident]
    relations = list()

    for index in range(len(indicators)):
        entities.append(indicators[index])
        # incident -> all indicators
        relation = {
            "data": {
                "source": 0,
                "target": index + 1,
                "key": "related_indicators",
                "source_type": "incident",
                "target_type": "indicator",
                "type": "relation",
            }
        }
        if indicators[index].get("relationship"):
            relation["data"]["relationship"] = indicators[index].pop("relationship")
        relations.append(relation)

    for index in range(len(reports)):
        entities.append(reports[index])
        relation = {
            "data": {
                "source": len(indicators) + index + 1,
                "target": 0,
                "key": "incidents",
                "source_type": "report",
                "target_type": "incident",
                "type": "relation",
            }
        }
        if reports[index].get("relationship"):
            relation["data"]["relationship"] = reports[index].pop("relationship")
        relations.append(relation)

    for obj in misp_objects:
        for index in range(len(obj)):
            entities.append(obj)
            relations.append(
                {
                    "data": {
                        "source": 0,
                        "target": len(entities) - 1,
                        "key": "related_indicators",
                        "source_type": "incident",
                        "target_type": "indicator",
                        "type": "relation",
                    }
                }
            )

    # galaxy clusters -> incident
    for index in range(len(galaxy_clusters)):
        entities.append(galaxy_clusters[index])
        relations.append(
            {
                "data": {
                    "source": 0,
                    "target": len(entities) - 1,
                    "key": get_relation_key(galaxy_clusters[index].get("data")),
                    "source_type": "incident",
                    "target_type": galaxy_clusters[index]["data"].get("type"),
                    "type": "relation",
                }
            }
        )

    return {"type": "linked-entities", "entities": entities, "relations": relations}


def get_galaxy_type(galaxy_type: str) -> str:
    # ttp_galaxy_types: rat, tool, ransomeware, mitre-intrusion-set, exploit-kit, tds,
    # attack-pattern, mitre-malware, banker,
    threat_actor_galaxy_types = ["threat-actor", "microsoft-activity-group"]
    cours_of_action_galaxy_types = ["course-of-action", "preventive-measure"]
    if galaxy_type in threat_actor_galaxy_types:
        return "threat-actor"
    elif galaxy_type in cours_of_action_galaxy_types:
        return "course-of-action"
    return "ttp"


def make_cluster_entity(cluster: dict) -> dict:
    galaxy_type = get_galaxy_type(cluster.get("type"))
    if type(cluster.get("meta")) is list:
        references = []
    else:
        references = cluster.get("meta").get("refs") or []
    func_mapping = {
        "ttp": create_ttp,
        "threat-actor": create_threat_actor,
        "course-of-action": create_course_of_action,
    }
    information_source = create_information_source(
        identity_name=cluster.get("source"),
        description="Event Creator",
        references=references,
    )
    cluster_entity = func_mapping[galaxy_type](
        stix_id="{{http://misp-project.org}}{}-{}".format(
            galaxy_type, str(uuid.uuid5(uuid.NAMESPACE_X500, cluster.get("value")))
        ),
        title=cluster.get("value"),
        description=cluster.get("description"),
        information_source=information_source,
    )
    return cluster_entity


def make_galaxy_cluster_entities(galaxy_clusters: list) -> list:
    return [make_cluster_entity(cluster) for cluster in galaxy_clusters]


def make_galaxy_entities(galaxies: list) -> list:
    galaxy_clusters = []
    for galaxy in galaxies:
        galaxy_clusters.extend(
            make_galaxy_cluster_entities(galaxy.get("GalaxyCluster"))
        )
    return galaxy_clusters


def get_description(event: dict) -> list:
    description = []
    for attr in event.get("Attribute"):
        if attr.get("type") in ["comment", "text"]:
            description.append(sanitize_description(attr))
    return description


def get_references(event: dict) -> list:
    refs = []
    for attr in event.get("Attribute"):
        if attr["category"] == "External analysis" and attr["type"] == "link":
            refs.append(attr["value"].replace("[.]", "."))
    return refs


def set_reference(entities: list, url: str, _id: str) -> None:
    if not url:
        return
    url = "{}/events/view/{}".format(url.rstrip("/"), _id)
    for entity in entities:
        inf_source = (
            "information_source"
            if entity["data"]["type"] != "indicator"
            else "producer"
        )
        entity["data"][inf_source]["references"] = entity["data"][inf_source].get(
            "references", []
        ) + [url]


def make_observables_from_uuid(event: dict, uuids: list) -> list:
    observables = []
    for _uuid in uuids:
        for attribute in event.get("Attribute"):
            if _uuid == attribute.get("uuid"):
                observables.extend(make_observables(attribute))
    return observables


def add_yara_or_snort_rule(attribute: dict) -> list:
    test_mechanism = {
        "test_mechanism_type": attribute.get("type"),
        "type": "test-mechanism",
    }
    if attribute.get("type") == "yara":
        test_mechanism["rule"] = {"value": attribute.get("value")}
    elif attribute.get("type") == "snort":
        test_mechanism["rules"] = [{"value": attribute.get("value")}]
    return [test_mechanism]


def make_incident_indicators_and_reports(event: dict) -> dict:
    # first check if MISP event is generate by our platform
    correlation = {}
    for i, attribute in enumerate(event.get("Attribute")):
        if attribute.get("comment") == "MISP EIQ event metadata":
            correlation = json.loads(attribute.get("value"))
            event.get("Attribute").pop(i)

    incident_correlation = (
        correlation["entity-mappings"]["root"]["observables"] if correlation else []
    )
    tlp_from_tag = None
    if event.get("prioritize_tlp") and event.get("Tag"):
        tlp_from_tag = get_tlp_from_tag(event.get("Tag"))
    # For all attributes with distribution value '5'(inherit),
    # we set tlp color based on the event's distribution value.
    # distribution['5'] will contain the value of the event's tlp color
    distribution["5"] = tlp_from_tag or distribution.get(str(event.get("distribution")))
    meta_description = f"\neiq_meta:dist{event['distribution']}"

    observables = make_observables_from_uuid(event, incident_correlation)

    indicators, reports = make_indicators_and_reports(event, correlation)

    description = get_description(event) + [meta_description]
    references = []
    if event.get("misp_url"):
        references.append(
            "{}/events/view/{}".format(
                event.get("misp_url").rstrip("/"), event.get("id")
            )
        )

    stix_id = correlation.get(
        "origin-id"
    ) or "{http://misp-project.org}incident-" + event.get("uuid")
    latest_entity = get_latest_entity_version(stix_id)
    _id = stix_id if not latest_entity else latest_entity.meta.get("stix_id")

    affected_assets = (
        [
            {"type": "affected-asset", "observable": observable}
            for observable in observables
        ]
        if observables
        else None
    )
    tlp_colour = tlp_from_tag or distribution.get(str(event.get("distribution")))
    references.extend(get_references(event))
    information_source = create_information_source(
        identity_name="",
        description="Event Creator",
        references=references,
    )
    incident = create_incident(
        stix_id=_id,
        title=event.get("info"),
        timestamp=datetime.datetime.fromtimestamp(
            int(event.get("publish_timestamp"))
        ).isoformat(),
        threat_start_time=datetime.datetime.strptime(
            event.get("date"), "%Y-%m-%d"
        ).isoformat(),
        description="\n".join(description),
        information_source=information_source,
        tlp_color=tlp_colour,
        affected_assets=affected_assets,
    )
    misp_objects_indicators = []

    if event.get("Object"):
        obj_indicators = [make_misp_object_indicator(obj) for obj in event["Object"]]
        misp_objects_indicators.extend(obj_indicators)

    set_reference(misp_objects_indicators, event.get("misp_url"), event.get("id"))

    galaxy_clusters = []

    if event.get("Galaxy"):
        galaxy_clusters = make_galaxy_entities(event["Galaxy"])

    add_taxonomies_and_tags_to_entities([incident], event.get("Tag", []))
    add_taxonomies_and_tags_to_entities(
        indicators + misp_objects_indicators,
        event.get("Tag", []),
        datetime.datetime.fromtimestamp(
            int(event.get("publish_timestamp"))
        ).isoformat(),
    )
    # return linked entities for incident,
    # indicator, reports, ttp and misp_objects
    return make_linked_entities_iirt(
        incident, indicators, reports, misp_objects_indicators, galaxy_clusters
    )


def make_misp_object_indicator(misp_object: dict) -> dict:
    description = misp_object.get("description") or ""
    timestamps, observables, description_attr = process_object_attribute(misp_object)
    description = f"<p>{description}</p>{description_attr}"
    title_sufix = get_title_sufix(misp_object)

    indicator = {
        "data": {
            "id": "{http://misp-project.org}indicator-" + misp_object.get("uuid"),
            "title": (
                "{} - {}".format(misp_object.get("name"), title_sufix),
                "{}".format(misp_object.get("name")),
            )[title_sufix is None],
            "type": "indicator",
            "timestamp": datetime.datetime.fromtimestamp(max(timestamps)).isoformat(),
            "producer": {
                "description": "Event Creator",
                "type": "information-source",
                "identity": {"name": "", "type": "identity"},
            },
        },
        "meta": {
            "estimated_threat_start_time": datetime.datetime.fromtimestamp(
                int(misp_object.get("timestamp", 0))
            ).isoformat()
        },
    }
    if observables:
        indicator["data"]["observable"] = {
            "type": "observable",
            "composition": observables,
            "composition_operator": "OR",
        }
    description_meta = f"<p>eiq_meta:dist{misp_object['distribution']}:misp_object</p>"
    indicator["data"]["description"] = f"<html>{description}{description_meta}</html>"
    tlp_colour = distribution.get(str(misp_object.get("distribution")))
    if tlp_colour:
        indicator["meta"]["tlp_color"] = tlp_colour
    if misp_object.get("to_ids"):
        indicator["meta"]["tags"] = list(indicator["meta"].get("tags", [])) + ["IDS"]
    return indicator


def process_object_attribute(misp_object: dict) -> Tuple:
    description = ""
    observables, timestamps = [], []
    for attribute in misp_object.get("Attribute"):
        tags = ""
        if attribute.get("Tag"):
            at_tags = ""
            for tag in attribute["Tag"]:
                at_tags += f"<li>{tag['name']}</li>"
            tags = f"<ul>{at_tags}</ul>"
        description += f"""<p>
                <ul>
                    <li>Category: {attribute['category']}</li>
                    <li>Type: {attribute['type']}</li>
                    <li>Object relation: {attribute['object_relation']}</li>
                    <li>Value: {sanitize_string(xml.sax.saxutils.escape(attribute['value']))}</li>
                    <li>Comment: {sanitize_string(xml.sax.saxutils.escape(attribute['comment']))}</li>
                    <li>Distribution: {attribute['distribution']}</li>
                    <li>To ids: {attribute['to_ids']}</li>
                    <li>Timestamp: {attribute['timestamp']}</li>
                    <li>Tags: {tags}</li>
                </ul>
            </p>"""  # noqa E501
        timestamps.append(int(attribute.get("timestamp", 0)))
        observables.extend(make_observables(attribute))
    return timestamps, observables, description


def get_title_sufix(misp_object: dict) -> str:  # noqa: C901
    if misp_object["comment"]:
        return misp_object["comment"]
    if misp_object["name"] == "file":
        for attr in misp_object["Attribute"]:
            if attr.get("type") in ["filename", "md5", "sha1", "sha256"]:
                return extract_types.get(attr.get("type"))
    if misp_object["name"] == "virustotal-report":
        for attr in misp_object["Attribute"]:
            if attr.get("type") == "link":
                return attr.get("value").split("/")[4]
    if misp_object["name"] == "domain-ip":
        for attr in misp_object["Attribute"]:
            if attr.get("type") in ["ip", "domain"]:
                return extract_types.get(attr.get("type"))
    if misp_object["name"] == "victim":
        for attr in misp_object["Attribute"]:
            if attr.get("type") == "name":
                return attr.get("value")
    if misp_object["name"] == "microblog":
        for attr in misp_object["Attribute"]:
            if attr.get("type") == "text" and len(attr.get("value")) < 50:
                return attr.get("value")
    if misp_object["name"] == "elf-section":
        for attr in misp_object["Attribute"]:
            if attr.get("object_relation") == "name":
                return attr.get("value")


def get_tlp_colors_and_marking_structure(misp_object: dict) -> tuple:
    tlps = []
    marking_structure = None
    for attribute in misp_object.get("Attribute", []):
        for tag in attribute.get("Tag", []):
            if tag["name"].startswith("tlp"):
                tlp_values = tag["name"].split(":")[1].split(" ")
                tlp = tlp_values[0]
                if len(tlp_values) > 1:
                    marking_structure = tlp_values[1]
                tlps.append(tlp.upper())
    return tlps, marking_structure


def get_most_restrictive(colors: list) -> Optional[str]:
    colors = map(TlpColor.parse, colors)
    try:
        return max(colors).name
    except ValueError:
        return


def make_observables(attribute: dict) -> list:
    observables = []
    if attribute.get("type") in formats:
        if "|" in attribute.get("type"):
            values = attribute.get("value").split("|")
            types = attribute.get("type").split("|")
            for observable in [
                make_observable(types[0], values[0]),
                make_observable(types[1], values[1]),
            ]:
                if observable:
                    observables.append(observable)
        else:
            observable = make_observable(
                attribute["type"], attribute["value"].replace("[.]", ".")
            )
            if observable:
                observables.append(observable)

    return observables


def make_observable(kind: str, value: Union[str, int]) -> Optional[dict]:
    """Helper to make an observable."""
    fmt = formats.get(kind.lower())
    if fmt is None:
        return None
    return {
        "type": "observable",
        "object": {
            "type": "cybox-object",
            "properties_xml": fmt.format(value),
            "properties_xml_type": properties_xml_types.get(kind.lower()),
        },
    }


def add_inf_source(event: dict, linked_entities: dict) -> dict:
    identity_name = ""
    if event.get("Orgc"):
        identity_name = event["Orgc"].get("name")
    for entity in linked_entities["entities"]:
        if entity["data"].get("type") == "indicator":
            entity["data"]["producer"]["identity"]["name"] = identity_name
        else:
            entity["data"]["information_source"]["identity"]["name"] = identity_name
    return linked_entities


def sanitize_string(value: str) -> str:
    # \u0000-\u0008, \u000B-\u001F, \u007F-\u0084, \u0086-\u009F
    invalid_cdata_chars = (
        list(range(8))
        + list(range(11, 31))
        + list(range(127, 132))
        + list(range(134, 159))
    )
    cdata_sanitizer = dict.fromkeys(invalid_cdata_chars)
    sanitized_value = value.translate(cdata_sanitizer)

    return sanitized_value


def sanitize_description(attribute: dict) -> str:
    """
    Repair UTF-16 text that is transferred as UTF-8,
    and return it as a formatted string.
    """
    attribute["value"] = sanitize_string(attribute.get("value"))
    return "{} - {} - {}".format(
        attribute["category"], attribute["type"], attribute["value"]
    )


def transform_misp_request_list(event: dict, key: str) -> dict:
    """
    Handles MISP format where a list of events is supplied in a 'request' list.
    """
    all_linked_entities = {"type": "linked-entities", "entities": [], "relations": []}
    for ev in event.get(key):
        ev = ev["Event"]
        linked_entities = make_incident_indicators_and_reports(ev)
        linked_entities = add_inf_source(ev, linked_entities)
        all_linked_entities["entities"].extend(linked_entities["entities"])
        all_linked_entities["relations"].extend(linked_entities["relations"])

    return all_linked_entities


@transformer(incoming_content_types=[misp_content])
def transform(blob: bytes) -> dict:
    log.info("Transformer started")
    event = json.loads(blob)

    if event.get("entities"):
        return event

    # Handling for user uploaded MISP formats that bypass provider
    if event.get("Event"):
        event = event["Event"]

    # Handling for 'request' formatted JSON with multiple events
    if event.get("request"):
        return transform_misp_request_list(event, "request")
    elif event.get("response"):
        return transform_misp_request_list(event, "response")

    # Standard handling
    linked_entities = make_incident_indicators_and_reports(event)

    linked_entities = add_inf_source(event, linked_entities)

    log.info("Transformer finished successfully")
    return linked_entities
