from eiq_ext import Extension

from . import misp_enricher, misp_incoming, misp_outgoing, packer, transformers


def prepare_extension():
    return Extension(
        name=__name__,
        supported_api_version="1.0",
        description="MISP API",
        transformers=[transformers.transform],
        providers=[misp_incoming.fetch_misp_events],
        enrichers=[misp_enricher.enrich_misp_events],
        integrations=[misp_outgoing.MISPIntegration],
        packers=[packer.to_misp_json],
    )
