import datetime
import json
import uuid
from typing import Any, Union

import dateutil.parser
import structlog
from lxml import etree  # nosec

from eiq.platform import db
from eiq.platform.entities import Entity
from eiq_ext import declare_content_type
from eiq_ext.legacy import (
    PackedContent,
    count_entities,
    entities_packer,
    get_platform_version,
)


log = structlog.get_logger(__name__)

distribution_and_publish = {"distribution": "0", "publish": False}
tlp_to_distribution = {
    "RED": "0",
    "AMBER": "1",
    "GREEN": "2",
    "WHITE": "3",
    "null": None,
}
extract_types = {
    "hash-sha1": "sha1",
    "hash-sha256": "sha256",
    "email": "email-src",
    "port": "port",
    "ipv4": "ip-src",
    "hash-sha512": "sha512",
    "domain": "domain",
    "hash-md5": "md5",
    "uri": "uri",
    "file": "filename",
    "mutex": "mutex",
    "malware": "malware",
    "host": "hostname",
    "yara": "yara",
    "snort": "snort",
}
taxonomy_map = {
    # Kill chain taxonomies
    "kill-chain:Reconnaissance": "Kill chain phase - Reconnaissance",
    "kill-chain:Weaponization": "Kill chain phase - Weaponization",
    "kill-chain:Delivery": "Kill chain phase - Delivery",
    "kill-chain:Exploitation": "Kill chain phase - Exploitation",
    "kill-chain:Installation": "Kill chain phase - Installation",
    "kill-chain:Command and Control": "Kill chain phase - Command and Control",
    "kill-chain:Actions on Objectives": "Kill chain phase - Actions on Objectives",
    # Admiralty scale taxonomies
    # source-reliability
    'admiralty-scale:source-reliability="a"': "Admiralty Code - Completely reliable",
    'admiralty-scale:source-reliability="b"': "Admiralty Code - Usually reliable",
    'admiralty-scale:source-reliability="c"': "Admiralty Code - Fairly reliable",
    'admiralty-scale:source-reliability="d"': "Admiralty Code - Not usually reliable",
    'admiralty-scale:source-reliability="e"': "Admiralty Code - Unreliable",
    'admiralty-scale:source-reliability="f"': (
        "Admiralty Code - " "Reliability cannot be judged"
    ),
    # information-credibility
    'admiralty-scale:information-credibility="1"': (
        "Admiralty Code - " "Confirmed by other sources"
    ),
    'admiralty-scale:information-credibility="2"': "Admiralty Code - Probably True",
    'admiralty-scale:information-credibility="3"': "Admiralty Code - Possibly True",
    'admiralty-scale:information-credibility="4"': "Admiralty Code - Doubtful",
    'admiralty-scale:information-credibility="5"': "Admiralty Code - Improbable",
    'admiralty-scale:information-credibility="6"': (
        "Admiralty Code - " "Truth cannot be judged"
    ),
}
misp_json = declare_content_type(
    id="urn:misp_upload.com:json:1.0",
    name="MISP JSON model",
    description="MISP JSON model",
    content_groups=["eiq.outgoing-transports.misp_upload"],
    file_extension="json",
    mime_type="application/json",
)
ui_schema = [
    {
        "label": "Select distribution",
        "required": False,
        "multiple": False,
        "type": "select",
        "name": "distribution",
        "default": "0",
        "options": [
            {"value": "0", "name": "Your organisation only (default) - RED"},
            {"value": "1", "name": "This community only - AMBER"},
            {"value": "2", "name": "Connected communities - GREEN"},
            {"value": "3", "name": "All communities - WHITE"},
            {"value": None, "name": "No distribution"},
        ],
        "hint": "Select distribution for events and attributes",
    },
    {
        "label": "Publish event after upload",
        "name": "publish",
        "type": "checkbox",
        "default": False,
        "hint": "Publish event after upload",
    },
]


@entities_packer(
    outgoing_content_types=[misp_json],
    supported_update_strategies=["REPLACE", "APPEND"],
    include_relations=True,
    paginate_relations=False,
    include_entity_updates_chain=True,
    ui_form_schema=ui_schema,
)
def to_misp_json(
    stream: Any, *, feed: Any, is_diff: bool = False, **kwargs
) -> PackedContent:
    log.info("Packer started")
    """Package using the MISP format."""
    distribution_and_publish["distribution"] = (
        feed.content_configuration["distribution"]
        if feed.content_configuration["distribution"] != "null"
        else None
    )
    distribution_and_publish["publish"] = feed.content_configuration["publish"]
    entity_stream_elements = list(stream)
    packed_entities = [e.entity_dict for e in entity_stream_elements]
    entity_counts = count_entities(packed_entities)
    entities, versions, timestamps = classify_entities(packed_entities)
    misp_json_events = []
    used_entities = set()
    for entity in entities:
        if entities[entity]["type"] == "incident":
            used_entities.add(entity)
            misp_json_events.append(
                make_event(entity, entities, versions, used_entities)
            )
    unlinked_entities = set(entities.keys()).difference(used_entities)
    attributes = make_unlinked_atributes(unlinked_entities, entities, versions)
    content = {
        "content-type": misp_json.id,
        "timestamp": get_package_timestamp(timestamps),
        "platform-version": get_platform_version(),
        "outgoing_feed_name": feed.name,
        "events": misp_json_events,
        "entity_counts": entity_counts,
        "attributes": attributes,
    }
    json_content = json.dumps(
        content, indent=4, ensure_ascii=False, sort_keys=True
    ).encode()
    log.info("Packer finished succesfully")
    return PackedContent(json_content)


def classify_entities(packed_entities: list) -> tuple:
    entities = {}
    versions = {}
    relations = {}
    timestamps = []
    for entity in packed_entities:
        if not entity.get("data") or entity.get("meta", {}).get("is_unresolved_idref"):
            continue
        if entity["data"].get("timestamp", ""):
            timestamps.append(entity["data"].get("timestamp", ""))
        if entity["data"].get("type") == "incident":
            entities[entity["id"]] = {
                "event": entity["id"],
                "entity_body": entity,
                "type": "incident",
                "id": entity["data"]["id"],
                "attrs": [],
                "versions": [],
            }
        elif entity["data"].get("type") in ("indicator", "report"):
            entities[entity["id"]] = {
                "event": "",
                "entity_body": entity,
                "type": entity["data"]["type"],
                "id": entity["data"]["id"],
                "attrs": [],
                "versions": [],
                "object": "",
                "relationship": "",
            }
        elif entity["data"].get("subtype", "") == "stix_update_of":
            versions[entity["data"]["source"]] = (
                entity["data"]["target"],
                entity["data"]["target_stix_id"],
            )
        elif entity["data"].get("type") == "relation" and (
            entity["data"].get("target_type") == "indicator"
            or entity["data"].get("source_type") == "report"
        ):
            relations[entity["data"]["target"]] = relations.get(
                entity["data"]["target"], []
            ) + [entity["data"]]
    classify_relations(relations, entities)

    return entities, versions, timestamps


def classify_relations(relations: dict, entities: dict) -> None:  # noqa: C901
    for indicator_relations in relations.values():
        for relation in indicator_relations:
            if relation["source_type"] == "incident":
                entities[relation["source"]]["attrs"].append(relation["target"])
                try:
                    entities[relation["target"]]["event"] = relation["source"]
                    if relation.get("relationship"):
                        entities[relation["target"]]["relationship"] = relation.get(
                            "relationship"
                        )
                except KeyError:
                    pass
            elif relation["target_type"] == "incident":
                try:
                    entities[relation["target"]]["attrs"].append(relation["source"])
                    entities[relation["source"]]["event"] = relation["target"]
                    if relation.get("relationship"):
                        entities[relation["source"]]["relationship"] = relation.get(
                            "relationship"
                        )
                except KeyError:
                    pass
            else:
                try:
                    entities[relation["source"]]["attrs"].append(relation["target"])
                    entities[relation["target"]]["object"] = relation["source"]
                    entities[relation["target"]]["event"] = relations[
                        relation["source"]
                    ][0]["source"]
                    if relation.get("relationship"):
                        entities[relation["target"]]["relationship"] = relation.get(
                            "relationship"
                        )
                except KeyError:
                    pass


def make_event(  # noqa: C901
    entity: str, entities: dict, versions: dict, used_entities: set
) -> dict:
    attributes = []
    incident = entities[entity]["entity_body"]
    all_versions = get_all_versions(entities[entity]["event"], versions)
    if not all_versions:
        all_versions.append(entities[entity]["id"])
    # every ID has UUID at the end and it has 36 chars
    event_uuid = all_versions[-1][-36:]  # magic number
    tags = get_tags(incident)

    try:
        timestamp = dateutil.parser.parse(incident["data"].get("timestamp")).timestamp()
    except ValueError:
        timestamp = incident["data"].get("timestamp")
    # set tags from incident and tlp value as tag
    misp_event = {
        "uuid": event_uuid,
        "timestamp": timestamp,
        "info": incident["data"].get("title"),
        "published": distribution_and_publish["publish"],
        "Tag": tags,
        "Attribute": [],
        "Object": [],
    }
    set_distribution(misp_event, incident)
    correlation = {
        "origin-id": all_versions[-1],
        "entity-mappings": {"root": {"observables": []}},
    }
    # get all extracts from incident observables parse them as attributes
    # and add them to correlation attribute
    for extract in incident["extracts"]:
        if extract["kind"] in extract_types:
            extract_uuid = str(
                uuid.uuid5(uuid.NAMESPACE_DNS, event_uuid + extract["value"])
            )
            attributes.append(
                {
                    "type": extract_types[extract["kind"]],
                    "value": extract["value"],
                    "uuid": extract_uuid,
                    "to_ids": False,
                }
            )
            set_distribution(attributes[-1], incident)
            correlation["entity-mappings"]["root"]["observables"].append(extract_uuid)
    for attr in entities[entity]["attrs"]:
        if attr not in entities:
            continue
        used_entities.add(attr)
        entity = entities[attr]
        if entity["attrs"]:
            used_entities.update(entity["attrs"])
            misp_event["Object"].append(pack_object(entity, entities))
        elif (
            entity["entity_body"]["data"]
            .get("description", "")
            .endswith(":misp_object</p></html>")
        ):
            misp_event["Object"].append(pack_object_in_postmodern_way(entity))
        elif entity["type"] == "indicator":
            attributes.extend(
                make_indicator_attributes(entity, correlation, event_uuid)
            )
        else:
            attributes.append(make_report_attribute(entity, correlation))
    attributes.append(make_meta_attribute(correlation, event_uuid))
    misp_event["Attribute"] = attributes
    return misp_event


def pack_object_in_postmodern_way(object_: dict) -> dict:
    obj = object_["entity_body"]
    description_html = etree.fromstring(obj["data"]["description"])
    description_ps = description_html.findall("p")
    misp_object = {
        "name": obj["data"]["title"].split(" - ")[0],
        "description": description_ps[0].text,
        # every ID has UUID at the end and it has 36 chars
        "uuid": obj["data"]["id"][-36:],  # magic number
        "timestamp": dateutil.parser.parse(obj["data"].get("timestamp")).timestamp(),
        # TODO: Extract and add comment.
        # At the moment, it is not possible to extract comment from entity.
        # With some changes in the platform, which I hope will happen,
        # it will be possible. So, this particular TODO is here for the
        # future releases of the extension.
        "comment": "",
    }
    set_distribution(misp_object, obj)
    attributtes = []
    for attr in description_ps[1:-1]:
        lis = [x.text.split(": ", 1)[-1] for x in attr.findall(".//li")]
        (
            category,
            att_type,
            obj_relation,
            value,
            comment,
            distribution,
            to_ids,
            timestamp,
            *tags,
        ) = lis
        tags.remove("")
        attribute = {
            "type": att_type,
            "category": category or "",
            "to_ids": {"True": True}.get(to_ids, False),
            "timestamp": timestamp,
            "comment": comment or "",
            "object_relation": obj_relation or "",
            "distribution": distribution,
            "value": value,
            "Tag": tags,
        }
        attributtes.append(attribute)
    misp_object["Attribute"] = attributtes
    return misp_object


def pack_object(object_: dict, entities: dict) -> dict:
    obj = object_["entity_body"]
    misp_object = {
        "name": obj["data"]["title"].split(" - ")[0],
        "description": obj["data"].get("description", "").split("\neiq_meta:")[0],
        # every ID has UUID at the end and it has 36 chars
        "uuid": obj["data"]["id"][-36:],  # magic number
        "timestamp": dateutil.parser.parse(obj["data"].get("timestamp")).timestamp(),
        # TODO: Extract and add comment.
        # At the moment, it is not possible to extract comment from entity.
        # With some changes in the platform, which I hope will happen,
        # it will be possible. So, this particular TODO is here for the
        # future releases of the extension.
        "comment": "",
    }
    set_distribution(misp_object, obj)
    attributtes = []
    for attr in object_["attrs"]:
        indicator = entities.get(attr, {}).get("entity_body")
        if not indicator:
            continue
        if ":obj_rel-" not in indicator["data"].get("description", ""):
            continue
        to_ids = "IDS" in indicator["meta"].get("tags", [])
        tags = get_tags(indicator)
        description_list = indicator["data"].get("description", "").split("\n")
        description_meta = description_list[-1]
        category, type_, value = description_list[0].split(" - ")
        comment = (
            description_list[1].replace("Comment: ", "")
            if len(description_list) > 2
            else ""
        )
        attribute = {
            "type": type_,
            "category": category,
            "to_ids": to_ids,
            "timestamp": dateutil.parser.parse(
                indicator["data"].get("timestamp")
            ).timestamp(),
            "comment": comment,
            "object_relation": description_meta.split(":obj_rel-")[-1].split(":")[0],
            "value": value,
            "Tag": tags,
        }
        set_distribution(attribute, indicator)
        attributtes.append(attribute)
    misp_object["Attribute"] = attributtes
    return misp_object


def make_indicator_attributes(
    entity: dict, correlation: Union[list, dict], event_uuid: str = None
) -> list:
    attributes = []
    indicator = entity["entity_body"]
    event_uuid = event_uuid or entity["event"]
    extracts = get_indicator_extracts(indicator.get("extracts", []))
    comment = get_comment(indicator["data"].get("description") or "Other")
    observables_uuids = []
    to_ids = "IDS" in indicator["meta"].get("tags", [])
    for i, extract in enumerate(extracts):
        extract_uuid = str(
            uuid.uuid5(uuid.NAMESPACE_DNS, event_uuid + extract["value"])
        )
        if not extract.get("kind"):
            extract["kind"] = get_attribute_type(
                indicator["data"].get("description", "")
            )
        if "ip-dst" in indicator["data"].get("description", ""):
            extract["kind"] = extract["kind"].replace("ip-src", "ip-dst")
        tags = get_tags(indicator)
        attribute = {
            "uuid": extract_uuid,
            "type": extract["kind"],
            "value": extract["value"],
            "comment": comment,
            "to_ids": to_ids,
            "Tag": tags,
        }
        set_distribution(attribute, indicator)
        observables_uuids.append(extract_uuid)
        if len(indicator["data"].get("timestamp")) != 10:
            timestamp = dateutil.parser.parse(
                indicator["data"].get("timestamp")
            ).timestamp()
        else:
            timestamp = indicator["data"].get("timestamp")
        attribute["timestamp"] = timestamp
        attributes.append(attribute)
    ind_correlation = {
        "title": indicator["data"].get("title"),
        "observables": observables_uuids,
    }
    if entity.get("relationship"):
        ind_correlation["relationship"] = entity.get("relationship")
    if type(correlation) is dict and correlation.get("entity-mappings"):
        correlation["entity-mappings"][indicator["data"].get("id")] = ind_correlation
    elif not correlation:
        correlation.append(ind_correlation)

    return attributes


def make_report_attribute(entity: dict, correlation: dict) -> dict:
    report = entity["entity_body"]
    _uuid = report.get("id")
    to_ids = "IDS" in report["meta"].get("tags", [])
    value, attribute_type = get_report_info(report["data"])
    report_corellation = {"title": report["data"].get("title"), "observables": []}
    if entity.get("relationship"):
        report_corellation["relationship"] = entity.get("relationship")
    correlation["entity-mappings"][report["data"].get("id")] = report_corellation

    try:
        timestamp = dateutil.parser.parse(report["data"].get("timestamp")).timestamp()
    except ValueError:
        timestamp = report["data"].get("timestamp")
    attribute = {
        "uuid": _uuid[-36:],
        "timestamp": timestamp,
        "type": attribute_type,
        "value": value,
        "category": "External analysis",
        "comment": report["data"].get("short_description") or "",
        "to_ids": to_ids,
    }
    set_distribution(attribute, report)
    return attribute


def make_meta_attribute(correlation: dict, event_uuid: str) -> dict:
    correlation_uuid = uuid.uuid5(uuid.NAMESPACE_DNS, event_uuid)
    meta_attribute = {
        "type": "other",
        "uuid": str(correlation_uuid),
        "category": "Other",
        "value": json.dumps(correlation),
        "comment": "MISP EIQ event metadata",
        "distribution": "5",
    }
    return meta_attribute


def make_unlinked_atributes(
    unlinked_entities: list, entities: dict, versions: dict
) -> dict:
    attributes = {}
    packed_objects = set()
    for unlinked_entity in unlinked_entities:
        entity = entities[unlinked_entity]
        events_uuids = get_event_id(entity, unlinked_entity)
        if not events_uuids:
            continue
        if entity["attrs"] and unlinked_entity not in packed_objects:
            packed_objects.add(unlinked_entity)
            obj = pack_object(entity, entities)
            for event_uuid in events_uuids:
                attributes[event_uuid] = attributes.get(event_uuid, []) + [
                    {
                        "stix_id": entity["id"],
                        "correlation": "",
                        "attributes": "",
                        "versions": get_all_versions(unlinked_entity, versions),
                        "entity_id": unlinked_entity,
                        "object": obj,
                    }
                ]
        elif entity["entity_body"]["data"]["description"].endswith(
            ":misp_object</p></html>"
        ):
            packed_objects.add(unlinked_entity)
            obj = pack_object_in_postmodern_way(entity)
            for event_uuid in events_uuids:
                attributes[event_uuid] = attributes.get(event_uuid, []) + [
                    {
                        "stix_id": entity["id"],
                        "correlation": "",
                        "attributes": "",
                        "versions": get_all_versions(unlinked_entity, versions),
                        "entity_id": unlinked_entity,
                        "object": obj,
                    }
                ]
        elif not entity.get("object"):
            for event_uuid in events_uuids:
                corr = []
                ind_attrs = make_indicator_attributes(entity, corr, event_uuid)
                attributes[event_uuid] = attributes.get(event_uuid, []) + [
                    {
                        "stix_id": entity["id"],
                        "correlation": corr[0],
                        "attributes": ind_attrs,
                        "versions": get_all_versions(unlinked_entity, versions),
                        "entity_id": unlinked_entity,
                    }
                ]
    return attributes


def get_ref(entity_data: dict) -> str:
    refs = entity_data.get("information_source")
    if refs.get("references"):
        return refs.get("references")[0]
    return ""


def get_report_info(report_data: dict) -> tuple:
    ref = get_ref(report_data)
    if ref:
        return ref, "link"
    else:
        description = report_data.get("description").split("\neiq_meta")[0]
        return description, "text"


def get_indicator_extracts(extracts: list) -> list:
    filtered_extracts = []
    for extract in extracts:
        if extract.get("kind") in extract_types.keys():
            filtered_extracts.append(
                {
                    "value": extract.get("value"),
                    "kind": extract_types[extract.get("kind")],
                }
            )
    return filtered_extracts


def get_comment(description: str) -> str:
    comment = []
    rows = description.split("\n")
    for row in rows:
        if row.startswith("Comment:"):
            comment.append(row[9:])
    return "\n".join(comment)


def get_attribute_type(description: str) -> str:
    rows = description.split("\n")
    info = rows[0].split(" - ")
    if len(info) > 1:
        return info[1]
    return ""


def get_tags(entity: dict) -> list:
    tags = []
    meta_tags = entity["meta"].get("tags", [])
    try:
        meta_tags.remove("IDS")
    except ValueError:
        pass
    tags.extend(meta_tags)
    # add TLP value as tag
    tlp = entity["meta"].get("tlp_color")
    if tlp:
        tags.append("tlp:{}".format(tlp.lower()))
    taxonomies = entity["meta"].get("taxonomy_paths", [])
    for taxonomy in taxonomies:
        tag = taxonomy[-1]
        inverted_taxonomy_map = {v: k for k, v in taxonomy_map.items()}
        tags.append(inverted_taxonomy_map.get(tag, tag))
    return tags


def get_package_timestamp(timestamps: list) -> str:
    default = datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0)
    return max(timestamps, default=default.isoformat())


def set_distribution(attribute: dict, entity: dict) -> None:
    entity_dist = None
    if ":dist" in entity["data"].get("description", ""):
        entity_dist = entity["data"]["description"].split(":dist")[-1][0]
    distribution = tlp_to_distribution.get(entity["meta"].get("tlp_color"))
    if entity_dist == "5" or distribution is None:
        distribution = entity_dist
    if not distribution or distribution == "4":
        distribution = distribution_and_publish["distribution"]
    if distribution:
        attribute["distribution"] = distribution


def get_event_id(entity: dict, entity_id: str) -> list:
    if ":event_uuid-" in entity["entity_body"]["data"].get("description", ""):
        return [entity["entity_body"]["data"]["description"].split(":event_uuid-")[-1]]
    log.info("Looking into database for relations for entity.", entity_id=entity_id)
    events_ids = []
    entity_from_db = db.session.query(Entity).filter(Entity.id == entity_id).one()
    for relation in entity_from_db.incoming_stix_relations:
        if "incident" == relation.as_dict()["source_type"]:
            event_stix_id = relation.as_dict()["source"]
            log.info(
                "Looking into database for relations for event id.",
                event_id=event_stix_id,
            )
            incident = (
                db.session.query(Entity)
                .filter(Entity.id == event_stix_id)
                .one_or_none()
            )
            if incident is not None:
                events_ids.append(incident.as_dict()["_meta"]["stix_id"][-36:])
    return events_ids


def get_all_versions(entity_id: str, versions_ll: dict) -> list:
    versions = []
    while entity_id:
        entity_id, version = versions_ll.get(entity_id, (None, None))
        if version:
            versions.append(version)
    return versions
