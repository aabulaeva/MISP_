import eiq_ext


ext = eiq_ext.Extension(
    name=__name__,
    supported_api_version="1.0",
    description="Commons",
)
