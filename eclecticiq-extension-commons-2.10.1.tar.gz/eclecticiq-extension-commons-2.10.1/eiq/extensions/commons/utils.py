import datetime
from typing import List

import iso3166
import structlog
import validators

from eiq.platform.ingestion import _preprocessing
from eiq_ext import ExtractType


log = structlog.get_logger(__name__)

country_list = (
    "czech republic",
    "russia",
    "united states",
    "great britain",
    "united kingdom",
    "latvija",
)


def create_extract(
    kind: ExtractType,
    value: str,
    maliciousness: str = None,
    classification: str = None,
    diff: str = None,
    link_type: str = "observed",
) -> dict:
    if value is None or any(
        [
            kind is None,
            kind == ExtractType.URI and not validators.url(value),
            kind == ExtractType.DOMAIN and not validators.domain(value),
            kind == ExtractType.EMAIL and not validators.email(value),
            kind == ExtractType.IPV4 and not validators.ipv4(value),
            kind == ExtractType.IPV6 and not validators.ipv6(value),
            kind == ExtractType.HASH_MD5 and not validators.hashes.md5(value),
            kind == ExtractType.HASH_SHA1 and not validators.hashes.sha1(value),
            kind == ExtractType.HASH_SHA256 and not validators.hashes.sha256(value),
            kind == ExtractType.HASH_SHA512 and not validators.hashes.sha512(value),
            kind == ExtractType.COUNTRY
            and value.lower() not in country_list
            and iso3166.countries.get(value, None) is None,
            kind == ExtractType.COUNTRY_CODE
            and iso3166.countries.get(value, None) is None,
        ]
    ):
        log.error(f"Validation didn't pass for {kind} with this value {value}")
        return {}

    extract = {
        "kind": kind.value,
        "value": check_value(str(value), kind),
        "link_type": link_type,
    }
    # if maliciousness is given, then classification is "bad"
    if maliciousness and maliciousness in ["low", "medium", "high"]:
        extract["classification"] = "bad"
        extract["confidence"] = maliciousness
    if classification and classification in ["unknown", "good"]:
        extract["classification"] = classification
        extract.pop("confidence", None)
    if diff:
        extract["diff"] = diff
    return extract


def check_value(value, kind):
    if kind in (
        ExtractType.DOMAIN,
        ExtractType.EMAIL,
        ExtractType.CWE,
        ExtractType.CVE,
        ExtractType.HASH_MD5,
        ExtractType.HASH_SHA1,
        ExtractType.HASH_SHA256,
        ExtractType.HASH_SHA512,
    ):
        value = value.lower()
        if kind in (ExtractType.CVE, ExtractType.CWE):
            value = value.replace("cve-", "").replace("cwe-", "")
    elif kind in (ExtractType.INDUSTRY,):
        value = value.title()
    elif kind in (ExtractType.COUNTRY_CODE,):
        value = value.upper()
    return value


# This is information source that is going to be used for all the other entities.
def create_information_source(
    identity_name: str,
    references: list = None,
    role_values: list = None,
    description: str = None,
) -> dict:
    data = {
        "identity": {"name": identity_name, "type": "identity"},
        "type": "information-source",
    }
    if description:
        data["description"] = description
    if references:
        data["references"] = references
    if role_values:
        roles = []
        for role in role_values:
            roles.append(
                {
                    "value": role,
                    "vocab": (
                        "{http://stix.mitre.org/default_vocabularies-1}"
                        "InformationSourceRoleVocab-1.0"
                    ),
                }
            )
        data["roles"] = roles
    return data


def make_likely_impact(impact: str) -> dict:
    impact = impact.capitalize()
    if impact not in ["Low", "Medium", "High"]:
        impact = "Unknown"
    return {
        "type": "statement",
        "value": impact,
        "value_vocab": "{http://stix.mitre.org/default_vocabularies-1}"
        "HighMediumLowVocab-1.0",
    }


def make_confidence(confidence: str, description: str = None) -> dict:
    confidence = confidence.capitalize()
    if confidence not in ["Low", "Medium", "High"]:
        confidence = "Unknown"
    final_confidence = {
        "type": "confidence",
        "value": confidence,
        "value_vocab": "{http://stix.mitre.org/default_vocabularies-1}"
        "HighMediumLowVocab-1.0",
    }
    if description:
        final_confidence["description"] = description
    return final_confidence


def create_threat_actor_type(value):
    return {
        "type": "statement",
        "value": value,
        "value_vocab": "{http://stix.mitre.org/default_vocabularies-1}"
        "ThreatActorTypeVocab-1.0",
    }


def create_threat_actor_sophistication(value):
    return {
        "type": "statement",
        "value": value,
        "value_vocab": "{http://stix.mitre.org/default_vocabularies-1}"
        "ThreatActorSophisticationVocab-1.0",
    }


def create_motivation(value):
    return {
        "type": "statement",
        "value": value,
        "value_vocab": "{http://stix.mitre.org/default_vocabularies-1}"
        "MotivationVocab-1.1",
    }


def create_intended_effect(value):
    return {
        "type": "statement",
        "value": value,
        "value_vocab": "{http://stix.mitre.org/default_vocabularies-1}"
        "IntendedEffectVocab-1.0",
    }


def add_basic_data(
    data: dict,
    description: str = None,
    information_source: dict = None,
    timestamp: str = None,
    summary: str = None,
    observable: list = None,
) -> None:
    if information_source:
        data["data"]["information_source"] = information_source
    if description:
        data["data"]["description"] = description
    if timestamp:
        data["data"]["timestamp"] = timestamp
    if summary:
        data["data"]["short_description"] = summary
    if observable:
        data["data"]["observable"] = {
            "type": "observable",
            "composition": observable,
            "composition_operator": "OR",
        }


def add_meta(
    data: dict,
    observed_time: str = None,
    threat_start_time: str = None,
    threat_end_time: str = None,
    extracts: list = None,
    tags: list = None,
    tlp_color: str = None,
    half_life: str = None,
    taxonomy: list = None,
    taxonomy_paths: list = None,
) -> None:
    if observed_time:
        data["meta"]["estimated_observed_time"] = observed_time
    if threat_start_time:
        data["meta"]["estimated_threat_start_time"] = threat_start_time
    if threat_end_time:
        data["meta"]["estimated_threat_end_time"] = threat_end_time
    if extracts:
        data["meta"]["bundled_extracts"] = extracts
    if tags:
        data["meta"]["tags"] = sorted(list(set(tags)))
    if tlp_color:
        data["meta"]["tlp_color"] = tlp_color
    if half_life:
        data["meta"]["half_life"] = half_life
    if taxonomy:
        data["meta"]["taxonomy"] = taxonomy
    if taxonomy_paths:
        data["meta"]["taxonomy_paths"] = taxonomy_paths


def add_incident_data(
    data: dict,
    incident_discovery: str = None,
    initial_compromise: str = None,
    containment_achieved: str = None,
    first_malicious_action: str = None,
    discovery_precision: str = "second",
    compromise_precision: str = "second",
    containment_precision: str = "second",
    first_action_precision: str = "second",
) -> None:
    if incident_discovery:
        data["data"]["time_incident_discovery"] = incident_discovery
        data["data"]["time_incident_discovery_precision"] = discovery_precision
    if initial_compromise:
        data["data"]["time_initial_compromise"] = initial_compromise
        data["data"]["time_initial_compromise_precision"] = compromise_precision
    if containment_achieved:
        data["data"]["time_containment_achieved"] = containment_achieved
        data["data"]["time_containment_achieved_precision"] = containment_precision
    if first_malicious_action:
        data["data"]["time_first_malicious_action"] = first_malicious_action
        data["data"]["time_first_malicious_action_precision"] = first_action_precision


def add_sighting_data(
    sighting: dict,
    security_control_name: str = None,
    security_control_references: list = None,
    security_control_time_end: str = None,
    security_control_time_end_precision: str = "second",
    security_control_time_received: str = None,
    security_control_time_received_precision: str = "second",
    security_control_time_start: str = None,
    security_control_time_start_precision: str = "second",
    raw_events: str = None,
) -> None:
    if raw_events:
        sighting["data"]["raw_events"] = raw_events

    security_control = dict()
    if security_control_name:
        security_control.update(
            {"identity": {"name": security_control_name, "type": "identity"}}
        )
    if security_control_references:
        security_control.update({"references": security_control_references})
    if security_control_time_received:
        security_control.update(
            {
                "time_received": security_control_time_received,
                "time_received_precision": security_control_time_received_precision,
            }
        )
    if security_control_time_start:
        security_control.update(
            {
                "time_start": security_control_time_start,
                "time_start_precision": security_control_time_start_precision,
            }
        )
    if security_control_time_end:
        security_control.update(
            {
                "time_end": security_control_time_end,
                "time_end_precision": security_control_time_end_precision,
            }
        )
    if security_control:
        sighting["data"]["security_control"] = security_control


def proccess_transformed_data(transformed: dict) -> List[dict]:
    transformed_package = _preprocessing.process_linked_entities(transformed)

    entity_dicts = []
    for input_entity in transformed_package.all():
        entity_dict = {
            "id": str(input_entity.id),
            "data": input_entity.data,
            "meta": input_entity.meta,
            "attachments": [
                {"data": a.data, "filename": a.filename}
                for a in input_entity.input_attachments
            ],
            "sources": [{"name": s} for s in input_entity.external_sources],
        }
        entity_dicts.append(entity_dict)

    return entity_dicts


def ensure_aware(
    value: datetime.datetime, default: datetime.timezone = datetime.timezone.utc
) -> datetime.datetime:
    """
    Make sure datetimes carry a time zone.
    Interpret naive datetime instances as UTC.
    """
    if value and value.tzinfo is None:
        return value.replace(tzinfo=default)
    return value
