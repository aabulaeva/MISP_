from eiq.platform.entities._validators import validate_entity_data

from .utils import add_basic_data, add_incident_data, add_meta, add_sighting_data


def create_report(
    stix_id: str,
    title: str,
    description: str = None,
    short_description: str = None,
    information_source: dict = None,
    observed_time: str = None,
    threat_start_time: str = None,
    threat_end_time: str = None,
    timestamp: str = None,
    extracts: list = None,
    tags: list = None,
    summary: str = None,
    intents: list = None,
    extraction_ignore_paths: list = None,
    attachments: list = None,
    tlp_color: str = None,
    half_life: int = None,
    observable: list = None,
    taxonomy: list = None,
    taxonomy_paths: list = None,
    relationship: str = None,
) -> dict:
    data = {
        "data": {"id": stix_id, "title": title, "type": "report"},
        "meta": {},
    }
    add_basic_data(
        data, description, information_source, timestamp, summary, observable
    )
    add_meta(
        data,
        observed_time,
        threat_start_time,
        threat_end_time,
        extracts,
        tags,
        tlp_color,
        half_life,
        taxonomy,
        taxonomy_paths,
    )
    if intents:
        data["data"]["intents"] = intents
    if extraction_ignore_paths:
        data["meta"]["extraction_ignore_paths"] = extraction_ignore_paths
    if attachments:
        data["attachments"] = attachments
    if short_description:
        data["data"]["short_description"] = short_description
    if relationship:
        data["relationship"] = relationship
    validate_entity_data(data.get("data"))
    return data


def create_indicator(
    stix_id: str,
    title: str,
    description: str = None,
    information_source: dict = None,
    types: list = None,
    observed_time: str = None,
    threat_start_time: str = None,
    threat_end_time: str = None,
    confidence: dict = None,
    timestamp: str = None,
    extracts: list = None,
    tags: list = None,
    summary: str = None,
    extraction_ignore_paths: list = None,
    tlp_color: str = None,
    half_life: int = None,
    observable: list = None,
    taxonomy: list = None,
    taxonomy_paths: list = None,
    likely_impact: dict = None,
    test_mechanisms: list = None,
    relationship: str = None,
) -> dict:
    data = {
        "data": {"id": stix_id, "title": title, "type": "indicator"},
        "meta": {},
    }
    add_basic_data(data, description, None, timestamp, summary, observable)
    add_meta(
        data,
        observed_time,
        threat_start_time,
        threat_end_time,
        extracts,
        tags,
        tlp_color,
        half_life,
        taxonomy,
        taxonomy_paths,
    )
    if information_source:
        data["data"]["producer"] = information_source
    if types:
        data["data"]["types"] = types
    if confidence:
        data["data"]["confidence"] = confidence
    if extraction_ignore_paths:
        data["meta"]["extraction_ignore_paths"] = extraction_ignore_paths
    if likely_impact:
        data["data"]["likely_impact"] = likely_impact
    if test_mechanisms:
        data["data"]["test_mechanisms"] = test_mechanisms
    if relationship:
        data["relationship"] = relationship
    validate_entity_data(data.get("data"))
    return data


def create_ttp(
    stix_id: str,
    title: str,
    information_source: dict = None,
    description: str = None,
    observed_time: str = None,
    threat_start_time: str = None,
    threat_end_time: str = None,
    timestamp: str = None,
    extracts: list = None,
    tags: list = None,
    summary: str = None,
    extraction_ignore_paths: list = None,
    tlp_color: str = None,
    half_life: int = None,
    observable: list = None,
    taxonomy: list = None,
    taxonomy_paths: list = None,
    behaviour: dict = None,
    victim_targeting: dict = None,
    intended_effects: list = None,
) -> dict:
    data = {
        "data": {"id": stix_id, "title": title, "type": "ttp"},
        "meta": {},
    }
    add_basic_data(
        data, description, information_source, timestamp, summary, observable
    )
    add_meta(
        data,
        observed_time,
        threat_start_time,
        threat_end_time,
        extracts,
        tags,
        tlp_color,
        half_life,
        taxonomy,
        taxonomy_paths,
    )
    if extraction_ignore_paths:
        data["meta"]["extraction_ignore_paths"] = extraction_ignore_paths
    if behaviour:
        data["data"]["behavior"] = behaviour
    if victim_targeting:
        data["data"]["victim_targeting"] = victim_targeting
    if intended_effects:
        data["data"]["intended_effects"] = intended_effects
    validate_entity_data(data.get("data"))
    return data


def create_exploit_target(
    stix_id: str,
    title: str,
    description: str = None,
    information_source: dict = None,
    observed_time: str = None,
    threat_start_time: str = None,
    threat_end_time: str = None,
    timestamp: str = None,
    extracts: list = None,
    tags: list = None,
    summary: str = None,
    extraction_ignore_paths: list = None,
    tlp_color: str = None,
    half_life: int = None,
    observable: list = None,
    taxonomy: list = None,
    taxonomy_paths: list = None,
    vulnerabilities: list = None,
    weaknesses: list = None,
) -> dict:
    data = {
        "data": {"id": stix_id, "title": title, "type": "exploit-target"},
        "meta": {},
    }
    add_basic_data(
        data, description, information_source, timestamp, summary, observable
    )
    add_meta(
        data,
        observed_time,
        threat_start_time,
        threat_end_time,
        extracts,
        tags,
        tlp_color,
        half_life,
        taxonomy,
        taxonomy_paths,
    )
    if extraction_ignore_paths:
        data["meta"]["extraction_ignore_paths"] = extraction_ignore_paths
    if vulnerabilities:
        data["data"]["vulnerabilities"] = vulnerabilities
    if weaknesses:
        data["data"]["weaknesses"] = weaknesses
    validate_entity_data(data.get("data"))
    return data


def create_threat_actor(
    stix_id: str,
    title: str,
    description: str = None,
    information_source: dict = None,
    observed_time: str = None,
    threat_start_time: str = None,
    threat_end_time: str = None,
    confidence: dict = None,
    timestamp: str = None,
    extracts: list = None,
    tags: list = None,
    summary: str = None,
    extraction_ignore_paths: list = None,
    attachments=None,
    tlp_color: str = None,
    half_life: int = None,
    observable: list = None,
    taxonomy: list = None,
    taxonomy_paths: list = None,
    motivations: list = None,
    actor_types: list = None,
    intended_effects: list = None,
    sophistication: list = None,
    actor_identity: str = None,
) -> dict:
    data = {
        "data": {"id": stix_id, "title": title, "type": "threat-actor"},
        "meta": {},
    }
    add_basic_data(
        data, description, information_source, timestamp, summary, observable
    )
    add_meta(
        data,
        observed_time,
        threat_start_time,
        threat_end_time,
        extracts,
        tags,
        tlp_color,
        half_life,
        taxonomy,
        taxonomy_paths,
    )
    if confidence:
        data["data"]["confidence"] = confidence
    if extraction_ignore_paths:
        data["meta"]["extraction_ignore_paths"] = extraction_ignore_paths
    if attachments:
        data["attachments"] = attachments
    if motivations:
        data["data"]["motivations"] = motivations
    if intended_effects:
        data["data"]["intended_effects"] = intended_effects
    if actor_types:
        data["data"]["types"] = actor_types
    if sophistication:
        data["data"]["sophistication"] = sophistication
    if actor_identity:
        data["data"]["identity"] = {"name": actor_identity, "type": "identity"}
    validate_entity_data(data.get("data"))
    return data


def create_incident(
    stix_id: str,
    title: str,
    description: str = None,
    information_source: dict = None,
    observed_time: str = None,
    threat_start_time: str = None,
    threat_end_time: str = None,
    confidence: dict = None,
    timestamp: str = None,
    extracts: list = None,
    tags: list = None,
    summary: str = None,
    extraction_ignore_paths: list = None,
    tlp_color: str = None,
    half_life: int = None,
    observable: list = None,
    taxonomy: list = None,
    taxonomy_paths: list = None,
    impact_assessment: dict = None,
    victims: list = None,
    incident_discovery: str = None,
    initial_compromise: str = None,
    containment_achieved: str = None,
    first_malicious_action: str = None,
    discovery_precision: str = "second",
    compromise_precision: str = "second",
    containment_precision: str = "second",
    first_action_precision: str = "second",
    affected_assets: list = None,
) -> dict:
    data = {
        "data": {"id": stix_id, "title": title, "type": "incident"},
        "meta": {},
    }
    add_basic_data(
        data, description, information_source, timestamp, summary, observable
    )
    add_meta(
        data,
        observed_time,
        threat_start_time,
        threat_end_time,
        extracts,
        tags,
        tlp_color,
        half_life,
        taxonomy,
        taxonomy_paths,
    )
    add_incident_data(
        data,
        incident_discovery,
        initial_compromise,
        containment_achieved,
        first_malicious_action,
        discovery_precision,
        compromise_precision,
        containment_precision,
        first_action_precision,
    )
    if confidence:
        data["data"]["confidence"] = confidence
    if extraction_ignore_paths:
        data["meta"]["extraction_ignore_paths"] = extraction_ignore_paths
    if impact_assessment:
        data["data"]["impact_assessment"] = impact_assessment
    if victims:
        data["data"]["victims"] = victims
    if affected_assets:
        data["data"]["affected_assets"] = affected_assets
    validate_entity_data(data.get("data"))
    return data


def create_course_of_action(
    stix_id: str,
    title: str,
    description: str = None,
    information_source: dict = None,
    observed_time: str = None,
    threat_start_time: str = None,
    threat_end_time: str = None,
    timestamp: str = None,
    extracts: list = None,
    tags: list = None,
    summary: str = None,
    extraction_ignore_paths: list = None,
    tlp_color: str = None,
    half_life: int = None,
    observable: list = None,
    taxonomy: list = None,
    taxonomy_paths: list = None,
) -> dict:
    data = {
        "data": {"id": stix_id, "title": title, "type": "course-of-action"},
        "meta": {},
    }
    add_basic_data(
        data, description, information_source, timestamp, summary, observable
    )
    add_meta(
        data,
        observed_time,
        threat_start_time,
        threat_end_time,
        extracts,
        tags,
        tlp_color,
        half_life,
        taxonomy,
        taxonomy_paths,
    )
    if extraction_ignore_paths:
        data["meta"]["extraction_ignore_paths"] = extraction_ignore_paths
    validate_entity_data(data.get("data"))
    return data


def create_campaign(
    stix_id: str,
    title: str,
    description: str = None,
    information_source: dict = None,
    observed_time: str = None,
    threat_start_time: str = None,
    threat_end_time: str = None,
    confidence: dict = None,
    timestamp: str = None,
    extracts: list = None,
    tags: list = None,
    attachments=None,
    tlp_color: str = None,
    half_life: int = None,
    observable: list = None,
    taxonomy: list = None,
    taxonomy_paths: list = None,
    intended_effects: list = None,
    names: list = None,
    handling: list = None,
    status_campaign: str = None,
):
    data = {
        "data": {
            "id": stix_id,
            "title": title,
            "intended_effects": intended_effects,
            "names": names,
            "status": status_campaign,
            "type": "campaign",
        },
        "meta": {},
    }
    add_basic_data(data, description, information_source, timestamp, None, observable)
    add_meta(
        data,
        observed_time,
        threat_start_time,
        threat_end_time,
        extracts,
        tags,
        tlp_color,
        half_life,
        taxonomy,
        taxonomy_paths,
    )

    if attachments:
        data["attachments"] = attachments
    if confidence:
        data["data"]["confidence"] = confidence
    if handling:
        data["data"]["handling"] = handling
    validate_entity_data(data.get("data"))
    return data


def create_sighting(
    stix_id: str,
    title: str,
    description: str = None,
    information_source: dict = None,
    observed_time: str = None,
    threat_start_time: str = None,
    threat_end_time: str = None,
    confidence: dict = None,
    timestamp: str = None,
    extracts: list = None,
    tags: list = None,
    summary: str = None,
    extraction_ignore_paths: list = None,
    tlp_color: str = None,
    half_life: int = None,
    observable: list = None,
    taxonomy: list = None,
    taxonomy_paths: list = None,
    likely_impact: dict = None,
    security_control_name: str = None,
    security_control_references: list = None,
    security_control_time_end: str = None,
    security_control_time_end_precision: str = None,
    security_control_time_received: str = None,
    security_control_time_received_precision: str = None,
    security_control_time_start: str = None,
    security_control_time_start_precision: str = None,
    raw_events: str = None,
) -> dict:
    sighting = {
        "data": {"id": stix_id, "type": "eclecticiq-sighting", "title": title},
        "meta": dict(),
    }
    add_basic_data(
        sighting, description, information_source, timestamp, summary, observable
    )
    add_meta(
        sighting,
        observed_time,
        threat_start_time,
        threat_end_time,
        extracts,
        tags,
        tlp_color,
        half_life,
        taxonomy,
        taxonomy_paths,
    )
    add_sighting_data(
        sighting,
        security_control_name,
        security_control_references,
        security_control_time_end,
        security_control_time_end_precision,
        security_control_time_received,
        security_control_time_received_precision,
        security_control_time_start,
        security_control_time_start_precision,
        raw_events,
    )
    if confidence:
        sighting["data"]["confidence"] = confidence
    if extraction_ignore_paths:
        sighting["meta"]["extraction_ignore_paths"] = extraction_ignore_paths
    if likely_impact:
        sighting["data"]["impact"] = likely_impact
    validate_entity_data(sighting.get("data"))
    return sighting
