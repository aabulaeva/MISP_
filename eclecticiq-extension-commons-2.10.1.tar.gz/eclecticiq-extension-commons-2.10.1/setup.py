from setuptools import find_packages, setup


setup(
    name="eclecticiq-extension-commons",
    version="2.10.1",
    description="Commons",
    url="https://www.eclecticiq.com/",
    author="EclecticIQ",
    author_email="info@eclecticiq.com",
    license="Proprietary License",
    long_description="This is extension that provides mutual functions and templates"
    "that can be used in every extension",
    long_description_content_type="text/plain",
    classifiers=["Private :: Do Not Upload"],
    packages=find_packages(),
    namespace_packages=["eiq"],
    install_requires=[
        "eclecticiq-platform-extensions-api == 2.10.*",
        "iso3166",
        "validators",
    ],
    include_package_data=True,
    entry_points={"eiq.extensions": ["commons = eiq.extensions.commons:ext"]},
)
